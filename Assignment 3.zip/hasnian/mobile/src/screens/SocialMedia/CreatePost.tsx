import React, { useState } from 'react';
import { View, Text, TextInput, StyleSheet, TouchableOpacity, ScrollView, Alert, Image } from 'react-native';
import client from '../../api/client';
import { Colors } from '../../constants/Colors';
import { ImagePlus, Send } from 'lucide-react-native';

const defaultImages = [
  'https://images.unsplash.com/photo-1682687220742-aba13b6e50ba?w=600&q=80',
  'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=600&q=80',
  'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=600&q=80',
  'https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?w=600&q=80',
];

const CreatePost = ({ navigation }: any) => {
  const [caption, setCaption] = useState('');
  const [selectedImage, setSelectedImage] = useState(defaultImages[0]);

  const handlePost = async () => {
    if (!caption.trim()) { Alert.alert('Error', 'Please write a caption'); return; }
    try {
      // Use the first user as the poster
      const usersRes = await client.get('/api/users');
      const userId = usersRes.data[0]?._id;
      await client.post('/api/posts', { title: caption.split(' ').slice(0, 3).join(' '), body: caption, image: selectedImage, userId });
      Alert.alert('Posted! 🎉', 'Your post is now live!', [{ text: 'OK', onPress: () => navigation.goBack() }]);
    } catch (err) { Alert.alert('Error', 'Could not create post'); }
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.heading}>New Post</Text>
      <Text style={styles.label}>Choose a photo</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 20 }}>
        {defaultImages.map((img, idx) => (
          <TouchableOpacity key={idx} onPress={() => setSelectedImage(img)} style={[styles.imgOption, selectedImage === img && styles.imgSelected]}>
            <Image source={{ uri: img }} style={styles.imgThumb} />
          </TouchableOpacity>
        ))}
      </ScrollView>
      <Image source={{ uri: selectedImage }} style={styles.preview} />
      <Text style={styles.label}>Caption</Text>
      <TextInput style={styles.input} multiline placeholder="Write a caption..." value={caption} onChangeText={setCaption} numberOfLines={4} textAlignVertical="top" />
      <TouchableOpacity style={styles.postBtn} onPress={handlePost}>
        <Send size={18} color="#fff" style={{ marginRight: 8 }} />
        <Text style={styles.postBtnText}>Share Post</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff', padding: 20 },
  heading: { fontSize: 24, fontWeight: 'bold', color: Colors.text, marginBottom: 20 },
  label: { fontSize: 14, fontWeight: '600', color: Colors.secondary, marginBottom: 10 },
  imgOption: { marginRight: 10, borderRadius: 12, borderWidth: 3, borderColor: 'transparent', overflow: 'hidden' },
  imgSelected: { borderColor: Colors.primary },
  imgThumb: { width: 70, height: 70, borderRadius: 10 },
  preview: { width: '100%', height: 250, borderRadius: 16, marginBottom: 20, backgroundColor: Colors.background },
  input: { backgroundColor: Colors.background, borderRadius: 12, padding: 15, fontSize: 15, minHeight: 100, marginBottom: 20, borderWidth: 1, borderColor: Colors.border },
  postBtn: { backgroundColor: Colors.primary, padding: 16, borderRadius: 14, flexDirection: 'row', justifyContent: 'center', alignItems: 'center' },
  postBtnText: { color: '#fff', fontSize: 17, fontWeight: 'bold' },
});

export default CreatePost;
