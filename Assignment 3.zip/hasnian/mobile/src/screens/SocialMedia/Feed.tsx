import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, Image, StyleSheet, TouchableOpacity, ActivityIndicator, Dimensions, ScrollView, TextInput } from 'react-native';
import client from '../../api/client';
import { Colors } from '../../constants/Colors';
import { Heart, MessageCircle, Send, Bookmark, PlusSquare, User, Search, Bell, MessageSquare } from 'lucide-react-native';

const { width } = Dimensions.get('window');

const Feed = ({ navigation }: any) => {
  const [posts, setPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [likedPosts, setLikedPosts] = useState<Set<string>>(new Set());
  const [search, setSearch] = useState('');
  const stories = posts.slice(0, 8);
  const filteredPosts = posts.filter((p: any) => (p.userId?.username || '').toLowerCase().includes(search.toLowerCase()) || (p.body || '').toLowerCase().includes(search.toLowerCase()));

  useEffect(() => { fetchPosts(); }, []);

  const fetchPosts = async () => {
    try { const res = await client.get('/api/posts'); setPosts(res.data); }
    catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  const handleLike = async (postId: string) => {
    if (likedPosts.has(postId)) return;
    try {
      await client.put(`/api/posts/${postId}/like`);
      setPosts(prev => prev.map(p => p._id === postId ? { ...p, likes: p.likes + 1 } : p));
      setLikedPosts(prev => new Set(prev).add(postId));
    } catch (err) { console.error(err); }
  };

  const renderPost = ({ item }: any) => (
    <View style={styles.postContainer}>
      <View style={styles.postHeader}>
        <TouchableOpacity style={styles.userRow} onPress={() => navigation.navigate('Profile', { userId: item.userId?._id })}>
          <Image source={{ uri: item.userId?.avatar }} style={styles.avatar} />
          <View>
            <Text style={styles.username}>{item.userId?.username || 'user'}</Text>
            <Text style={styles.location}>{item.title}</Text>
          </View>
        </TouchableOpacity>
      </View>

      <TouchableOpacity activeOpacity={0.9} onPress={() => handleLike(item._id)}>
        <Image source={{ uri: item.image }} style={styles.postImage} />
      </TouchableOpacity>

      <View style={styles.actions}>
        <View style={styles.leftActions}>
          <TouchableOpacity onPress={() => handleLike(item._id)} style={styles.actionBtn}>
            <Heart size={24} color={likedPosts.has(item._id) ? '#EF4444' : Colors.text} fill={likedPosts.has(item._id) ? '#EF4444' : 'none'} />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => navigation.navigate('Comments', { postId: item._id })} style={styles.actionBtn}>
            <MessageCircle size={24} color={Colors.text} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.actionBtn}>
            <Send size={22} color={Colors.text} />
          </TouchableOpacity>
        </View>
        <Bookmark size={24} color={Colors.text} />
      </View>

      <View style={styles.postInfo}>
        <Text style={styles.likes}>{item.likes?.toLocaleString()} likes</Text>
        <Text style={styles.caption}>
          <Text style={styles.captionUser}>{item.userId?.username} </Text>
          {item.body}
        </Text>
        <TouchableOpacity onPress={() => navigation.navigate('Comments', { postId: item._id })}>
          <Text style={styles.viewComments}>View all {item.commentsCount} comments</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.topBar}>
        <Text style={styles.logo}>Socialite</Text>
        <View style={styles.topActions}>
          <TouchableOpacity onPress={() => navigation.navigate('CreatePost')} style={{ marginRight: 15 }}>
            <PlusSquare size={26} color={Colors.text} />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => navigation.navigate('Profile')}>
            <User size={26} color={Colors.text} />
          </TouchableOpacity>
        </View>
      </View>
      <View style={styles.searchWrap}>
        <Search size={16} color={Colors.secondary} />
        <TextInput placeholder="Search users or posts" value={search} onChangeText={setSearch} style={styles.searchInput} />
        <Bell size={18} color={Colors.text} />
        <MessageSquare size={18} color={Colors.text} style={{ marginLeft: 8 }} />
      </View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.storiesRow}>
        {stories.map((story: any) => (
          <TouchableOpacity key={story._id} style={styles.storyItem}>
            <Image source={{ uri: story.userId?.avatar }} style={styles.storyAvatar} />
            <Text style={styles.storyName} numberOfLines={1}>{story.userId?.username}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
      <View style={styles.reelsCard}>
        <Text style={styles.reelsTitle}>Nature Reels</Text>
        <Text style={styles.reelsText}>Waterfalls • Mountains • Forest trails (demo reels)</Text>
      </View>
      {loading ? <ActivityIndicator size="large" color={Colors.primary} style={{ marginTop: 50 }} /> : (
        <FlatList data={filteredPosts} keyExtractor={(item) => item._id} renderItem={renderPost} showsVerticalScrollIndicator={false} />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  topBar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 15, paddingVertical: 12, borderBottomWidth: 0.5, borderBottomColor: Colors.border },
  logo: { fontSize: 24, fontWeight: 'bold', fontStyle: 'italic', color: Colors.text },
  topActions: { flexDirection: 'row', alignItems: 'center' },
  searchWrap: { margin: 10, marginTop: 8, borderWidth: 1, borderColor: Colors.border, backgroundColor: '#fff', borderRadius: 12, paddingHorizontal: 10, flexDirection: 'row', alignItems: 'center', height: 42 },
  searchInput: { flex: 1, marginLeft: 8, fontSize: 13 },
  storiesRow: { paddingHorizontal: 10, marginBottom: 8, maxHeight: 80 },
  storyItem: { alignItems: 'center', marginRight: 12, width: 58 },
  storyAvatar: { width: 52, height: 52, borderRadius: 26, borderWidth: 2, borderColor: '#8B5CF6' },
  storyName: { fontSize: 10, color: Colors.text, marginTop: 2 },
  reelsCard: { marginHorizontal: 10, marginBottom: 8, backgroundColor: '#F1F5F9', borderRadius: 12, padding: 12 },
  reelsTitle: { fontWeight: '700', color: Colors.text },
  reelsText: { color: Colors.textSecondary, marginTop: 2, fontSize: 12 },
  postContainer: { marginBottom: 5 },
  postHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 12 },
  userRow: { flexDirection: 'row', alignItems: 'center' },
  avatar: { width: 36, height: 36, borderRadius: 18, marginRight: 10, backgroundColor: Colors.border },
  username: { fontWeight: 'bold', fontSize: 14, color: Colors.text },
  location: { fontSize: 12, color: Colors.secondary },
  postImage: { width: width, height: width * 0.85, backgroundColor: Colors.background },
  actions: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 12, paddingVertical: 10 },
  leftActions: { flexDirection: 'row', alignItems: 'center' },
  actionBtn: { marginRight: 14 },
  postInfo: { paddingHorizontal: 12, paddingBottom: 12 },
  likes: { fontWeight: 'bold', fontSize: 14, color: Colors.text },
  caption: { fontSize: 14, color: Colors.text, marginTop: 4, lineHeight: 20 },
  captionUser: { fontWeight: 'bold' },
  viewComments: { fontSize: 13, color: Colors.secondary, marginTop: 4 },
});

export default Feed;
