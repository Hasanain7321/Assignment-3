import React, { useEffect, useState } from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity, ActivityIndicator, FlatList, Dimensions, TextInput, Alert, ScrollView } from 'react-native';
import client from '../../api/client';
import { Colors } from '../../constants/Colors';
import { Edit2, Save, Grid, Settings } from 'lucide-react-native';

const { width } = Dimensions.get('window');
const imgSize = (width - 6) / 3;

const Profile = ({ route, navigation }: any) => {
  const [user, setUser] = useState<any>(null);
  const [posts, setPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [formData, setFormData] = useState({ name: '', bio: '', email: '', phone: '' });

  useEffect(() => { fetchProfile(); }, []);

  const fetchProfile = async () => {
    try {
      const userId = route?.params?.userId;
      let userData;
      if (userId) {
        const res = await client.get(`/api/users/${userId}`);
        userData = res.data;
      } else {
        const usersRes = await client.get('/api/users');
        userData = usersRes.data[0];
      }
      setUser(userData);
      setFormData({ name: userData.name, bio: userData.bio || '', email: userData.email, phone: userData.phone });
      const postsRes = await client.get(`/api/users/${userData._id}/posts`);
      setPosts(postsRes.data);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  const handleSave = async () => {
    try {
      const res = await client.put(`/api/users/${user._id}`, formData);
      setUser(res.data);
      setEditing(false);
      Alert.alert('Saved!', 'Profile updated.');
    } catch (err) { Alert.alert('Error', 'Could not update.'); }
  };

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color={Colors.primary} /></View>;
  if (!user) return null;

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Image source={{ uri: user.avatar }} style={styles.avatar} />
        <View style={styles.statsRow}>
          <View style={styles.stat}><Text style={styles.statNum}>{user.postsCount}</Text><Text style={styles.statLabel}>Posts</Text></View>
          <View style={styles.stat}><Text style={styles.statNum}>{user.followers?.toLocaleString()}</Text><Text style={styles.statLabel}>Followers</Text></View>
          <View style={styles.stat}><Text style={styles.statNum}>{user.following}</Text><Text style={styles.statLabel}>Following</Text></View>
        </View>
      </View>

      <View style={styles.bioSection}>
        {editing ? (
          <>
            <TextInput style={styles.editInput} value={formData.name} onChangeText={v => setFormData({ ...formData, name: v })} placeholder="Name" />
            <TextInput style={styles.editInput} value={formData.bio} onChangeText={v => setFormData({ ...formData, bio: v })} placeholder="Bio" />
            <TextInput style={styles.editInput} value={formData.email} onChangeText={v => setFormData({ ...formData, email: v })} placeholder="Email" />
            <TouchableOpacity style={styles.saveBtn} onPress={handleSave}>
              <Save size={16} color="#fff" style={{ marginRight: 6 }} /><Text style={styles.saveBtnText}>Save</Text>
            </TouchableOpacity>
          </>
        ) : (
          <>
            <Text style={styles.name}>{user.name}</Text>
            <Text style={styles.bio}>{user.bio}</Text>
            <TouchableOpacity style={styles.editBtn} onPress={() => setEditing(true)}>
              <Edit2 size={14} color={Colors.text} style={{ marginRight: 6 }} /><Text style={styles.editBtnText}>Edit Profile</Text>
            </TouchableOpacity>
          </>
        )}
      </View>

      <View style={styles.gridHeader}>
        <Grid size={18} color={Colors.text} /><Text style={styles.gridLabel}>Posts</Text>
      </View>

      <View style={styles.gridContainer}>
        {posts.map((post: any) => (
          <TouchableOpacity key={post._id} onPress={() => navigation.navigate('PostDetails', { post })}>
            <Image source={{ uri: post.image }} style={styles.gridImage} />
          </TouchableOpacity>
        ))}
      </View>
      <View style={{ height: 30 }} />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', padding: 20 },
  avatar: { width: 80, height: 80, borderRadius: 40, backgroundColor: Colors.border },
  statsRow: { flex: 1, flexDirection: 'row', justifyContent: 'space-around', marginLeft: 20 },
  stat: { alignItems: 'center' },
  statNum: { fontSize: 18, fontWeight: 'bold', color: Colors.text },
  statLabel: { fontSize: 12, color: Colors.secondary, marginTop: 2 },
  bioSection: { paddingHorizontal: 20, paddingBottom: 15 },
  name: { fontSize: 16, fontWeight: 'bold', color: Colors.text },
  bio: { fontSize: 14, color: Colors.textSecondary, marginTop: 2 },
  editBtn: { flexDirection: 'row', alignItems: 'center', marginTop: 10, borderWidth: 1, borderColor: Colors.border, borderRadius: 8, padding: 8, justifyContent: 'center' },
  editBtnText: { fontSize: 14, fontWeight: '600', color: Colors.text },
  editInput: { borderWidth: 1, borderColor: Colors.border, borderRadius: 10, padding: 10, fontSize: 14, marginBottom: 8 },
  saveBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: Colors.accent, padding: 12, borderRadius: 10 },
  saveBtnText: { color: '#fff', fontWeight: 'bold' },
  gridHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 12, borderTopWidth: 1, borderTopColor: Colors.border },
  gridLabel: { marginLeft: 6, fontWeight: '600', color: Colors.text },
  gridContainer: { flexDirection: 'row', flexWrap: 'wrap' },
  gridImage: { width: imgSize, height: imgSize, margin: 1, backgroundColor: Colors.background },
});

export default Profile;
