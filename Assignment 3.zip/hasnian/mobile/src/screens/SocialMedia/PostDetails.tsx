import React from 'react';
import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity, Dimensions } from 'react-native';
import { Colors } from '../../constants/Colors';
import { Heart, MessageCircle, Send, Bookmark } from 'lucide-react-native';

const { width } = Dimensions.get('window');

const PostDetails = ({ route, navigation }: any) => {
  const { post } = route.params;

  return (
    <ScrollView style={styles.container}>
      <View style={styles.postHeader}>
        <View style={styles.userRow}>
          <Image source={{ uri: post.userId?.avatar || 'https://via.placeholder.com/150' }} style={styles.avatar} />
          <View>
            <Text style={styles.username}>{post.userId?.username || 'user'}</Text>
            <Text style={styles.location}>{post.title}</Text>
          </View>
        </View>
      </View>

      <Image source={{ uri: post.image }} style={styles.postImage} />

      <View style={styles.actions}>
        <View style={styles.leftActions}>
          <TouchableOpacity style={styles.actionBtn}>
            <Heart size={24} color={Colors.text} />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => navigation.navigate('Comments', { postId: post._id })} style={styles.actionBtn}>
            <MessageCircle size={24} color={Colors.text} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.actionBtn}>
            <Send size={22} color={Colors.text} />
          </TouchableOpacity>
        </View>
        <Bookmark size={24} color={Colors.text} />
      </View>

      <View style={styles.postInfo}>
        <Text style={styles.likes}>{post.likes?.toLocaleString() || 0} likes</Text>
        <Text style={styles.caption}>
          <Text style={styles.captionUser}>{post.userId?.username || 'user'} </Text>
          {post.body}
        </Text>
        <Text style={styles.date}>{new Date(post.createdAt).toDateString()}</Text>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  postHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 12 },
  userRow: { flexDirection: 'row', alignItems: 'center' },
  avatar: { width: 36, height: 36, borderRadius: 18, marginRight: 10, backgroundColor: Colors.border },
  username: { fontWeight: 'bold', fontSize: 14, color: Colors.text },
  location: { fontSize: 12, color: Colors.secondary },
  postImage: { width: width, height: width * 0.85, backgroundColor: Colors.background },
  actions: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 12, paddingVertical: 10 },
  leftActions: { flexDirection: 'row', alignItems: 'center' },
  actionBtn: { marginRight: 14 },
  postInfo: { paddingHorizontal: 12, paddingBottom: 12 },
  likes: { fontWeight: 'bold', fontSize: 14, color: Colors.text },
  caption: { fontSize: 14, color: Colors.text, marginTop: 4, lineHeight: 20 },
  captionUser: { fontWeight: 'bold' },
  date: { fontSize: 11, color: Colors.secondary, marginTop: 8 },
});

export default PostDetails;
