import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, Image, StyleSheet, TextInput, TouchableOpacity, ActivityIndicator, KeyboardAvoidingView, Platform } from 'react-native';
import client from '../../api/client';
import { Colors } from '../../constants/Colors';
import { Send } from 'lucide-react-native';

const Comments = ({ route }: any) => {
  const { postId } = route.params;
  const [comments, setComments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [text, setText] = useState('');

  useEffect(() => { fetchComments(); }, []);

  const fetchComments = async () => {
    try { const res = await client.get(`/api/posts/${postId}/comments`); setComments(res.data); }
    catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  const handleSend = async () => {
    if (!text.trim()) return;
    try {
      const res = await client.post(`/api/posts/${postId}/comments`, {
        userName: 'You', userAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&q=80', text: text.trim(),
      });
      setComments(prev => [res.data, ...prev]);
      setText('');
    } catch (err) { console.error(err); }
  };

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color={Colors.primary} /></View>;

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <FlatList
        data={comments}
        keyExtractor={(item) => item._id}
        contentContainerStyle={{ padding: 15 }}
        renderItem={({ item }) => (
          <View style={styles.commentRow}>
            <Image source={{ uri: item.userAvatar }} style={styles.avatar} />
            <View style={styles.commentBody}>
              <Text style={styles.commentUser}>{item.userName}</Text>
              <Text style={styles.commentText}>{item.text}</Text>
              <Text style={styles.commentTime}>{new Date(item.createdAt).toLocaleDateString()}</Text>
            </View>
          </View>
        )}
        ListEmptyComponent={<Text style={styles.emptyText}>No comments yet. Be the first!</Text>}
      />
      <View style={styles.inputRow}>
        <TextInput style={styles.input} placeholder="Add a comment..." value={text} onChangeText={setText} />
        <TouchableOpacity style={styles.sendBtn} onPress={handleSend}>
          <Send size={20} color="#fff" />
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  commentRow: { flexDirection: 'row', marginBottom: 18 },
  avatar: { width: 36, height: 36, borderRadius: 18, marginRight: 10, backgroundColor: Colors.border },
  commentBody: { flex: 1 },
  commentUser: { fontWeight: 'bold', fontSize: 14, color: Colors.text },
  commentText: { fontSize: 14, color: Colors.text, marginTop: 2, lineHeight: 20 },
  commentTime: { fontSize: 11, color: Colors.secondary, marginTop: 4 },
  emptyText: { textAlign: 'center', color: Colors.secondary, marginTop: 40, fontSize: 15 },
  inputRow: { flexDirection: 'row', alignItems: 'center', padding: 10, borderTopWidth: 1, borderTopColor: Colors.border },
  input: { flex: 1, backgroundColor: Colors.background, borderRadius: 20, paddingHorizontal: 16, paddingVertical: 10, fontSize: 15 },
  sendBtn: { marginLeft: 10, backgroundColor: Colors.primary, width: 40, height: 40, borderRadius: 20, justifyContent: 'center', alignItems: 'center' },
});

export default Comments;
