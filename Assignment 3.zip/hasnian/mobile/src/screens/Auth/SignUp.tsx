import React, { useState } from 'react';
import { ActivityIndicator, Alert, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { Colors } from '../../constants/Colors';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d).{8,}$/;
const usernameRegex = /^[a-zA-Z0-9_.-]{3,20}$/;

const SignUp = ({ navigation, route }: any) => {
  const { signUp } = useAuth();
  const { colors } = useTheme();
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!name || !username || !email || !password) return Alert.alert('Validation', 'All fields are required.');
    if (!emailRegex.test(email)) return Alert.alert('Validation', 'Enter a valid email.');
    if (!usernameRegex.test(username)) return Alert.alert('Validation', 'Username must be 3-20 chars and only letters, numbers, _, -, .');
    if (!passwordRegex.test(password)) return Alert.alert('Validation', 'Password must be 8+ chars with letters and numbers.');
    if (password !== confirmPassword) return Alert.alert('Validation', 'Passwords do not match.');
    try {
      setLoading(true);
      await signUp({ name: name.trim(), username: username.trim(), email: email.trim().toLowerCase(), password });
      const redirectTo = route?.params?.redirectTo;
      if (redirectTo) navigation.replace(redirectTo);
      else navigation.replace('Dashboard');
    } catch (err: any) {
      const message =
        err?.response?.data?.error ||
        (err?.code === 'ECONNABORTED' || err?.message?.includes('Network Error')
          ? 'Cannot connect to backend server. Start backend and check API URL.'
          : 'Unable to create account.');
      Alert.alert('Sign Up Failed', message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <Text style={[styles.title, { color: colors.text }]}>Create Account</Text>
        <TextInput placeholder="Full name" placeholderTextColor={colors.textSecondary} style={[styles.input, { borderColor: colors.border, color: colors.text }]} value={name} onChangeText={setName} />
        <TextInput placeholder="Username" placeholderTextColor={colors.textSecondary} style={[styles.input, { borderColor: colors.border, color: colors.text }]} autoCapitalize="none" value={username} onChangeText={setUsername} />
        <TextInput placeholder="Email" placeholderTextColor={colors.textSecondary} style={[styles.input, { borderColor: colors.border, color: colors.text }]} keyboardType="email-address" autoCapitalize="none" value={email} onChangeText={setEmail} />
        <TextInput placeholder="Password" placeholderTextColor={colors.textSecondary} style={[styles.input, { borderColor: colors.border, color: colors.text }]} secureTextEntry value={password} onChangeText={setPassword} />
        <TextInput placeholder="Confirm password" placeholderTextColor={colors.textSecondary} style={[styles.input, { borderColor: colors.border, color: colors.text }]} secureTextEntry value={confirmPassword} onChangeText={setConfirmPassword} />
        <TouchableOpacity style={[styles.button, { backgroundColor: colors.primary }]} onPress={handleSubmit} disabled={loading}>
          {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Sign Up</Text>}
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('SignIn', { redirectTo: route?.params?.redirectTo })}>
          <Text style={styles.link}>Already have an account? Sign in</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background, justifyContent: 'center', padding: 24 },
  card: { borderRadius: 18, borderWidth: 1, padding: 18, elevation: 2 },
  title: { fontSize: 30, fontWeight: '700', color: Colors.text, marginBottom: 20 },
  input: { backgroundColor: 'transparent', borderRadius: 12, borderWidth: 1, borderColor: Colors.border, paddingHorizontal: 14, height: 52, marginBottom: 12 },
  button: { backgroundColor: Colors.primary, height: 52, borderRadius: 12, justifyContent: 'center', alignItems: 'center', marginTop: 4 },
  buttonText: { color: '#fff', fontWeight: '700', fontSize: 16 },
  link: { marginTop: 16, textAlign: 'center', color: Colors.primary, fontWeight: '600' },
});

export default SignUp;
