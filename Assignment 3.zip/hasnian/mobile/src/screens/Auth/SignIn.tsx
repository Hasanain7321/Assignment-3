import React, { useState } from 'react';
import { ActivityIndicator, Alert, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { Colors } from '../../constants/Colors';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const SignIn = ({ navigation, route }: any) => {
  const { signIn } = useAuth();
  const { colors } = useTheme();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!email || !password) return Alert.alert('Validation', 'All fields are required.');
    if (!emailRegex.test(email)) return Alert.alert('Validation', 'Enter a valid email.');
    try {
      setLoading(true);
      await signIn(email.trim().toLowerCase(), password);
      const redirectTo = route?.params?.redirectTo;
      if (redirectTo) navigation.replace(redirectTo);
      else navigation.replace('Dashboard');
    } catch (err: any) {
      const message =
        err?.response?.data?.error ||
        (err?.code === 'ECONNABORTED' || err?.message?.includes('Network Error')
          ? 'Cannot connect to backend server. Start backend and check API URL.'
          : 'Unable to sign in.');
      Alert.alert('Sign In Failed', message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <Text style={[styles.title, { color: colors.text }]}>Welcome Back</Text>
        <Text style={[styles.subtitle, { color: colors.textSecondary }]}>Sign in to continue to your apps</Text>
        <TextInput placeholder="Email" placeholderTextColor={colors.textSecondary} style={[styles.input, { borderColor: colors.border, color: colors.text }]} keyboardType="email-address" autoCapitalize="none" value={email} onChangeText={setEmail} />
        <TextInput placeholder="Password" placeholderTextColor={colors.textSecondary} style={[styles.input, { borderColor: colors.border, color: colors.text }]} secureTextEntry value={password} onChangeText={setPassword} />
        <TouchableOpacity style={[styles.button, { backgroundColor: colors.primary }]} onPress={handleSubmit} disabled={loading}>
        {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Sign In</Text>}
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('SignUp', { redirectTo: route?.params?.redirectTo })}>
          <Text style={styles.link}>No account? Sign up</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background, justifyContent: 'center', padding: 24 },
  card: { borderRadius: 18, borderWidth: 1, padding: 18, elevation: 2 },
  title: { fontSize: 30, fontWeight: '700', color: Colors.text },
  subtitle: { fontSize: 14, color: Colors.textSecondary, marginBottom: 20 },
  input: { backgroundColor: 'transparent', borderRadius: 12, borderWidth: 1, borderColor: Colors.border, paddingHorizontal: 14, height: 52, marginBottom: 12 },
  button: { backgroundColor: Colors.primary, height: 52, borderRadius: 12, justifyContent: 'center', alignItems: 'center', marginTop: 4 },
  buttonText: { color: '#fff', fontWeight: '700', fontSize: 16 },
  link: { marginTop: 16, textAlign: 'center', color: Colors.primary, fontWeight: '600' },
});

export default SignIn;
