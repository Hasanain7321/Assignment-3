import React, { useState } from 'react';
import { Alert, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { Colors } from '../constants/Colors';
import { useAuth } from '../context/AuthContext';

const AccountProfile = ({ navigation }: any) => {
  const { user, updateProfile, signOut } = useAuth();
  const [name, setName] = useState(user?.name || '');
  const [username, setUsername] = useState(user?.username || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [bio, setBio] = useState(user?.bio || '');
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    try {
      setSaving(true);
      await updateProfile({ name, username, phone, bio });
      Alert.alert('Saved', 'Profile updated successfully.');
    } catch {
      Alert.alert('Error', 'Unable to update profile.');
    } finally {
      setSaving(false);
    }
  };

  if (!user) {
    return (
      <View style={styles.container}>
        <Text style={styles.guestTitle}>My Profile</Text>
        <Text style={styles.guestSubtitle}>
          Sign in once here to use the same authenticated session across all apps.
        </Text>
        <TouchableOpacity style={styles.saveBtn} onPress={() => navigation.navigate('SignIn')}>
          <Text style={styles.saveText}>Sign In</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.outlineBtn} onPress={() => navigation.navigate('SignUp')}>
          <Text style={styles.outlineText}>Create Account</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Email</Text>
      <Text style={styles.readonly}>{user?.email}</Text>
      <TextInput style={styles.input} placeholder="Name" value={name} onChangeText={setName} />
      <TextInput style={styles.input} placeholder="Username" value={username} onChangeText={setUsername} />
      <TextInput style={styles.input} placeholder="Phone" value={phone} onChangeText={setPhone} keyboardType="phone-pad" />
      <TextInput style={[styles.input, styles.bio]} placeholder="Bio" value={bio} onChangeText={setBio} multiline />
      <TouchableOpacity style={styles.saveBtn} onPress={handleSave} disabled={saving}>
        <Text style={styles.saveText}>{saving ? 'Saving...' : 'Save Profile'}</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.outlineBtn} onPress={signOut}>
        <Text style={styles.outlineText}>Sign Out</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background, padding: 20 },
  guestTitle: { fontSize: 28, fontWeight: '800', color: Colors.text, marginTop: 10 },
  guestSubtitle: { color: Colors.textSecondary, marginTop: 8, marginBottom: 20, lineHeight: 20 },
  label: { color: Colors.textSecondary, fontSize: 12 },
  readonly: { color: Colors.text, marginBottom: 12, fontWeight: '600' },
  input: { backgroundColor: '#fff', borderWidth: 1, borderColor: Colors.border, borderRadius: 12, paddingHorizontal: 12, height: 48, marginBottom: 10 },
  bio: { height: 100, textAlignVertical: 'top', paddingTop: 12 },
  saveBtn: { backgroundColor: Colors.primary, borderRadius: 12, alignItems: 'center', paddingVertical: 14, marginTop: 8 },
  saveText: { color: '#fff', fontWeight: '700' },
  outlineBtn: { borderWidth: 1, borderColor: Colors.border, borderRadius: 12, alignItems: 'center', paddingVertical: 14, marginTop: 10, backgroundColor: '#fff' },
  outlineText: { color: Colors.text, fontWeight: '600' },
});

export default AccountProfile;
