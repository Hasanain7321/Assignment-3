import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, ActivityIndicator, Alert, ScrollView } from 'react-native';
import { Colors } from '../../constants/Colors';
import client from '../../api/client';
import { CheckCircle2 } from 'lucide-react-native';

const SeatSelection = ({ route, navigation }: any) => {
  const { eventId, eventTitle } = route.params;
  const [seats, setSeats] = useState<any[]>([]);
  const [selectedSeats, setSelectedSeats] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { fetchSeats(); }, []);

  const fetchSeats = async () => {
    try { const res = await client.get(`/api/events/${eventId}/seats`); setSeats(res.data); }
    catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  const toggleSeat = (seat: any) => {
    if (seat.isBooked) return;
    const exists = selectedSeats.find(s => s._id === seat._id);
    if (exists) setSelectedSeats(selectedSeats.filter(s => s._id !== seat._id));
    else setSelectedSeats([...selectedSeats, seat]);
  };

  const totalPrice = selectedSeats.reduce((sum, s) => sum + s.price, 0);

  const confirmBooking = () => {
    if (selectedSeats.length === 0) { Alert.alert('Notice', 'Select at least one seat.'); return; }
    navigation.navigate('TicketSummary', {
      eventTitle, seats: selectedSeats.map(s => s.seatNumber), totalPrice,
      seatDetails: selectedSeats.map(s => ({ number: s.seatNumber, class: s.seatClass, price: s.price })),
    });
  };

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color={Colors.primary} /></View>;

  const rows = [...new Set(seats.map((s: any) => s.seatNumber.charAt(0)))];

  return (
    <View style={styles.container}>
      <Text style={styles.screenLabel}>SCREEN</Text>
      <View style={styles.screenLine} />

      <ScrollView contentContainerStyle={styles.seatsArea}>
        {rows.map(row => (
          <View key={row} style={styles.row}>
            <Text style={styles.rowLabel}>{row}</Text>
            {seats.filter((s: any) => s.seatNumber.charAt(0) === row).map((seat: any) => {
              const isSelected = selectedSeats.some(s => s._id === seat._id);
              const isVIP = seat.seatClass === 'VIP';
              return (
                <TouchableOpacity key={seat._id} disabled={seat.isBooked}
                  style={[styles.seat, seat.isBooked && styles.booked, isSelected && styles.selected, isVIP && !seat.isBooked && !isSelected && styles.vip]}
                  onPress={() => toggleSeat(seat)}>
                  <Text style={[styles.seatText, (seat.isBooked || isSelected) && { color: '#fff' }]}>{seat.seatNumber.slice(1)}</Text>
                </TouchableOpacity>
              );
            })}
          </View>
        ))}
      </ScrollView>

      <View style={styles.legend}>
        <View style={styles.legendItem}><View style={[styles.legendBox, { backgroundColor: '#f1f1f1' }]} /><Text style={styles.legendText}>Standard</Text></View>
        <View style={styles.legendItem}><View style={[styles.legendBox, { backgroundColor: '#FEF3C7' }]} /><Text style={styles.legendText}>VIP</Text></View>
        <View style={styles.legendItem}><View style={[styles.legendBox, { backgroundColor: Colors.secondary }]} /><Text style={styles.legendText}>Booked</Text></View>
        <View style={styles.legendItem}><View style={[styles.legendBox, { backgroundColor: Colors.accent }]} /><Text style={styles.legendText}>Selected</Text></View>
      </View>

      <View style={styles.footer}>
        <View>
          <Text style={styles.footerLabel}>{selectedSeats.length} seat(s) selected</Text>
          <Text style={styles.footerPrice}>Rs. {totalPrice.toLocaleString()}</Text>
        </View>
        <TouchableOpacity style={styles.confirmBtn} onPress={confirmBooking}>
          <CheckCircle2 color="#fff" size={18} style={{ marginRight: 6 }} />
          <Text style={styles.confirmText}>Continue</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  screenLabel: { textAlign: 'center', color: Colors.secondary, marginTop: 15, letterSpacing: 8, fontSize: 12 },
  screenLine: { height: 3, backgroundColor: Colors.primary, marginHorizontal: 50, marginTop: 8, borderRadius: 2 },
  seatsArea: { padding: 15, alignItems: 'center' },
  row: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  rowLabel: { width: 20, fontSize: 13, fontWeight: 'bold', color: Colors.secondary },
  seat: { width: 36, height: 36, margin: 3, backgroundColor: '#f1f1f1', borderRadius: 6, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: '#e0e0e0' },
  booked: { backgroundColor: Colors.secondary, borderColor: Colors.secondary },
  selected: { backgroundColor: Colors.accent, borderColor: Colors.accent },
  vip: { backgroundColor: '#FEF3C7', borderColor: '#F59E0B' },
  seatText: { fontWeight: 'bold', fontSize: 11, color: Colors.text },
  legend: { flexDirection: 'row', justifyContent: 'space-around', paddingVertical: 12, borderTopWidth: 1, borderTopColor: Colors.border },
  legendItem: { flexDirection: 'row', alignItems: 'center' },
  legendBox: { width: 14, height: 14, borderRadius: 3, marginRight: 5 },
  legendText: { fontSize: 11, color: Colors.secondary },
  footer: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 18, backgroundColor: '#fff', borderTopWidth: 1, borderTopColor: Colors.border },
  footerLabel: { fontSize: 13, color: Colors.secondary },
  footerPrice: { fontSize: 20, fontWeight: 'bold', color: Colors.text },
  confirmBtn: { flexDirection: 'row', backgroundColor: Colors.primary, paddingHorizontal: 20, paddingVertical: 14, borderRadius: 12, alignItems: 'center' },
  confirmText: { color: '#fff', fontSize: 15, fontWeight: 'bold' },
});

export default SeatSelection;
