import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { Colors } from '../../constants/Colors';
import { CheckCircle, Ticket, MapPin, Clock } from 'lucide-react-native';

const TicketSummary = ({ route, navigation }: any) => {
  const { eventTitle, seats, totalPrice, seatDetails } = route.params;
  const bookingId = `BK-${Date.now().toString().slice(-6)}`;

  return (
    <ScrollView style={styles.container}>
      <View style={styles.successBanner}>
        <CheckCircle size={48} color="#fff" />
        <Text style={styles.successText}>Booking Confirmed!</Text>
        <Text style={styles.bookingId}>#{bookingId}</Text>
      </View>

      <View style={styles.ticketCard}>
        <View style={styles.ticketHeader}>
          <Ticket size={20} color={Colors.primary} />
          <Text style={styles.eventTitle}>{eventTitle}</Text>
        </View>
        <View style={styles.divider} />

        <Text style={styles.sectionLabel}>SEATS</Text>
        {seatDetails?.map((s: any, idx: number) => (
          <View key={idx} style={styles.seatRow}>
            <Text style={styles.seatNum}>{s.number}</Text>
            <Text style={[styles.seatClass, s.class === 'VIP' && { color: '#B45309', backgroundColor: '#FEF3C7' }]}>{s.class}</Text>
            <Text style={styles.seatPrice}>Rs. {s.price}</Text>
          </View>
        ))}

        <View style={styles.divider} />
        <View style={styles.totalRow}>
          <Text style={styles.totalLabel}>Total Amount</Text>
          <Text style={styles.totalVal}>Rs. {totalPrice?.toLocaleString()}</Text>
        </View>

        <View style={styles.qrSection}>
          <View style={styles.qrPlaceholder}>
            <Text style={styles.qrText}>QR</Text>
          </View>
          <Text style={styles.qrHint}>Show this at the venue entrance</Text>
        </View>
      </View>

      <TouchableOpacity style={styles.doneBtn} onPress={() => navigation.popToTop()}>
        <Text style={styles.doneBtnText}>Done</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  successBanner: { backgroundColor: Colors.accent, padding: 35, alignItems: 'center' },
  successText: { color: '#fff', fontSize: 24, fontWeight: 'bold', marginTop: 12 },
  bookingId: { color: 'rgba(255,255,255,0.8)', fontSize: 14, marginTop: 4 },
  ticketCard: { backgroundColor: '#fff', margin: 20, borderRadius: 20, padding: 20, elevation: 4 },
  ticketHeader: { flexDirection: 'row', alignItems: 'center' },
  eventTitle: { fontSize: 20, fontWeight: 'bold', color: Colors.text, marginLeft: 10, flex: 1 },
  divider: { height: 1, backgroundColor: Colors.border, marginVertical: 15 },
  sectionLabel: { fontSize: 12, fontWeight: 'bold', color: Colors.secondary, letterSpacing: 2, marginBottom: 10 },
  seatRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 },
  seatNum: { fontSize: 16, fontWeight: 'bold', color: Colors.text, width: 40 },
  seatClass: { fontSize: 12, fontWeight: '600', color: Colors.secondary, backgroundColor: Colors.background, paddingHorizontal: 10, paddingVertical: 3, borderRadius: 6, overflow: 'hidden' },
  seatPrice: { fontSize: 14, fontWeight: '600', color: Colors.text },
  totalRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  totalLabel: { fontSize: 16, fontWeight: 'bold', color: Colors.text },
  totalVal: { fontSize: 22, fontWeight: 'bold', color: Colors.accent },
  qrSection: { alignItems: 'center', marginTop: 20 },
  qrPlaceholder: { width: 100, height: 100, backgroundColor: Colors.text, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
  qrText: { color: '#fff', fontSize: 24, fontWeight: 'bold' },
  qrHint: { fontSize: 12, color: Colors.secondary, marginTop: 8 },
  doneBtn: { margin: 20, backgroundColor: Colors.primary, padding: 16, borderRadius: 14, alignItems: 'center' },
  doneBtnText: { color: '#fff', fontSize: 17, fontWeight: 'bold' },
});

export default TicketSummary;
