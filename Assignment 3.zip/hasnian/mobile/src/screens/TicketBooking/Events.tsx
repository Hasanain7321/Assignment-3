import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity, ScrollView, Alert } from 'react-native';
import client from '../../api/client';
import { Colors } from '../../constants/Colors';
import { Bus, Clock, MapPin } from 'lucide-react-native';
import { useAuth } from '../../context/AuthContext';

const cities = ['Lahore', 'Islamabad', 'Karachi', 'Hyderabad', 'Peshawar', 'Multan'];

const Events = ({ navigation }: any) => {
  const { user } = useAuth();
  const [routes, setRoutes] = useState<any[]>([]);
  const [from, setFrom] = useState('Lahore');
  const [to, setTo] = useState('Islamabad');
  const [gender, setGender] = useState<'male' | 'female'>('male');
  const [bookedTickets, setBookedTickets] = useState<any[]>([]);

  useEffect(() => { fetchRoutes(); if (user) fetchTickets(); else setBookedTickets([]); }, [from, to, user]);

  const fetchRoutes = async () => {
    try { const res = await client.get('/api/routes', { params: { from, to } }); setRoutes(res.data); }
    catch (err) { console.error(err); }
  };

  const fetchTickets = async () => {
    try { const res = await client.get('/api/tickets'); setBookedTickets(res.data); }
    catch { setBookedTickets([]); }
  };

  const bookTicket = async (item: any) => {
    if (!user) {
      Alert.alert('Sign in required', 'Please sign in from My Profile before booking tickets.', [
        { text: 'Go to My Profile', onPress: () => navigation.navigate('AccountProfile') },
        { text: 'Cancel', style: 'cancel' },
      ]);
      return;
    }
    try {
      await client.post('/api/tickets', { from: item.from, to: item.to, busName: item.busName, travelDate: new Date(), gender, fare: item.fare });
      Alert.alert('Booked', `Ticket booked (${gender.toUpperCase()})`);
      fetchTickets();
    } catch (err: any) {
      Alert.alert('Booking failed', err?.response?.data?.error || 'Could not book ticket');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.sectionTitle}>Pakistan Routes</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.catBar}>
        {cities.map((city) => (
          <TouchableOpacity key={`from-${city}`} style={[styles.catChip, from === city && styles.catActive]} onPress={() => setFrom(city)}>
            <Text style={[styles.catText, from === city && { color: '#fff' }]}>From: {city}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.catBar}>
        {cities.map((city) => (
          <TouchableOpacity key={`to-${city}`} style={[styles.catChip, to === city && styles.catActive]} onPress={() => setTo(city)}>
            <Text style={[styles.catText, to === city && { color: '#fff' }]}>To: {city}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
      <View style={styles.genderRow}>
        {(['male', 'female'] as const).map((g) => (
          <TouchableOpacity key={g} style={[styles.genderChip, gender === g && styles.genderChipActive]} onPress={() => setGender(g)}>
            <Text style={[styles.genderText, gender === g && { color: '#fff' }]}>{g.toUpperCase()}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <FlatList
        data={routes}
        keyExtractor={(item: any) => item.id}
        contentContainerStyle={{ padding: 15 }}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <View style={styles.row}>
              <Text style={styles.title}>{item.from} {'->'} {item.to}</Text>
              <Bus size={20} color={Colors.primary} />
            </View>
            <View style={styles.detailRow}><MapPin size={13} color={Colors.secondary} /><Text style={styles.detailText}>{item.busName}</Text></View>
            <View style={styles.detailRow}><Clock size={13} color={Colors.secondary} /><Text style={styles.detailText}>{item.departure}</Text></View>
            <Text style={styles.price}>Rs. {item.fare}</Text>
            <TouchableOpacity style={styles.bookBtn} onPress={() => bookTicket(item)}>
              <Text style={styles.bookText}>Book Ticket</Text>
            </TouchableOpacity>
          </View>
        )}
      />

      <Text style={styles.sectionTitle}>Booked Tickets</Text>
      <FlatList
        data={bookedTickets}
        keyExtractor={(item: any) => item._id}
        contentContainerStyle={{ paddingHorizontal: 15, paddingBottom: 20 }}
        renderItem={({ item }) => (
          <View style={styles.ticketRow}>
            <Text style={styles.ticketText}>{item.from} {'->'} {item.to} ({item.gender})</Text>
            <Text style={[styles.ticketStatus, { color: item.isBooked ? '#10B981' : Colors.danger }]}>{item.isBooked ? 'Booked' : 'Not Booked'}</Text>
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  sectionTitle: { fontWeight: '700', color: Colors.text, fontSize: 15, marginTop: 10, marginHorizontal: 15 },
  catBar: { paddingHorizontal: 15, alignItems: 'center' },
  catChip: { paddingHorizontal: 16, paddingVertical: 8, backgroundColor: '#fff', borderRadius: 20, marginRight: 8, borderWidth: 1, borderColor: Colors.border },
  catActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  catText: { color: Colors.secondary, fontWeight: '600', fontSize: 13 },
  genderRow: { flexDirection: 'row', marginHorizontal: 15, marginVertical: 10 },
  genderChip: { paddingHorizontal: 14, paddingVertical: 8, backgroundColor: '#fff', borderRadius: 10, marginRight: 8, borderWidth: 1, borderColor: Colors.border },
  genderChipActive: { backgroundColor: '#0EA5E9', borderColor: '#0EA5E9' },
  genderText: { color: Colors.textSecondary, fontWeight: '600' },
  card: { backgroundColor: '#fff', borderRadius: 16, marginBottom: 12, padding: 14, elevation: 2 },
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  title: { fontSize: 17, fontWeight: 'bold', color: Colors.text, marginTop: 4 },
  detailRow: { flexDirection: 'row', alignItems: 'center', marginTop: 4 },
  detailText: { marginLeft: 5, color: Colors.secondary, fontSize: 12 },
  bookBtn: { backgroundColor: Colors.primary, padding: 10, borderRadius: 10, alignItems: 'center', marginTop: 8 },
  bookText: { color: '#fff', fontWeight: 'bold', fontSize: 13 },
  price: { color: Colors.accent, fontWeight: '700', marginTop: 6 },
  ticketRow: { backgroundColor: '#fff', borderRadius: 12, padding: 12, marginBottom: 8, flexDirection: 'row', justifyContent: 'space-between' },
  ticketText: { color: Colors.text, fontWeight: '600' },
  ticketStatus: { fontWeight: '700' },
});

export default Events;
