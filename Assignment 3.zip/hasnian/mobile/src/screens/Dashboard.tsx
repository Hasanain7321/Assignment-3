import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, ActivityIndicator } from 'react-native';
import { Colors } from '../constants/Colors';
import client from '../api/client';
import { ShoppingBag, Users, Ticket, Wallet, Truck, Database, Moon, Sun, UserCircle } from 'lucide-react-native';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';

const apps = [
  { id: 'Ecommerce', title: 'E-Commerce App', icon: ShoppingBag, color: '#3B82F6' },
  { id: 'SocialMedia', title: 'Social Media App', icon: Users, color: '#8B5CF6' },
  { id: 'TicketBooking', title: 'Ticket Booking App', icon: Ticket, color: '#F59E0B' },
  { id: 'ExpenseTracker', title: 'Expense Tracker', icon: Wallet, color: '#10B981' },
  { id: 'FoodDelivery', title: 'Food Delivery App', icon: Truck, color: '#EF4444' },
  { id: 'AccountProfile', title: 'My Profile', icon: UserCircle, color: '#0EA5E9' },
];

const Dashboard = ({ navigation }: any) => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const { isDark, toggleTheme, colors } = useTheme();

  const goToModule = (moduleId: string) => {
    navigation.navigate(moduleId);
  };

  const handleSeed = async () => {
    setLoading(true);
    try {
      await client.post('/api/seed');
      Alert.alert('Success', 'Database has been seeded with random test data!');
    } catch {
      Alert.alert('Error', 'Could not connect to server. Check IP address.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { backgroundColor: colors.primary }]}>
        <TouchableOpacity style={styles.themeIconBtn} onPress={toggleTheme}>
          {isDark ? <Sun size={16} color="#fff" /> : <Moon size={16} color="#fff" />}
        </TouchableOpacity>
        <View>
          <Text style={styles.title}>Main Dashboard</Text>
          <Text style={styles.subtitle}>Your all-in-one modular apps</Text>
        </View>
      </View>

      <View style={styles.grid}>
        {apps.map((app) => (
          <TouchableOpacity
            key={app.id}
            style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}
            onPress={() => goToModule(app.id)}
          >
            <View style={[styles.iconContainer, { backgroundColor: app.color + '20' }]}>
              <app.icon size={30} color={app.color} />
            </View>
            <Text style={[styles.cardTitle, { color: colors.text }]}>{app.title}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <TouchableOpacity 
        style={[styles.adminButton, { backgroundColor: colors.secondary }]} 
        onPress={handleSeed}
        disabled={loading}
      >
        {loading ? (
          <ActivityIndicator color="#fff" />
        ) : (
          <>
            <Database size={20} color="#fff" style={{ marginRight: 8 }} />
            <Text style={styles.adminButtonText}>Re-Initialize Test Data</Text>
          </>
        )}
      </TouchableOpacity>
      <TouchableOpacity style={[styles.loginCta, { backgroundColor: colors.surface, borderColor: colors.border }]} onPress={() => navigation.navigate('AccountProfile')}>
        <Text style={styles.loginCtaText}>{user ? 'Manage profile and session' : 'Sign in from My Profile for universal access'}</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: { padding: 26, paddingTop: 34, backgroundColor: Colors.primary, borderBottomLeftRadius: 28, borderBottomRightRadius: 28, position: 'relative' },
  themeIconBtn: { position: 'absolute', top: 16, right: 16, width: 34, height: 34, borderRadius: 17, justifyContent: 'center', alignItems: 'center', backgroundColor: 'rgba(255,255,255,0.2)' },
  title: { fontSize: 30, fontWeight: '800', color: '#fff' },
  subtitle: { fontSize: 14, color: '#e2e8f0', marginTop: 6 },
  grid: { padding: 20, flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
  card: {
    width: '47%',
    backgroundColor: '#fff',
    borderWidth: 1,
    borderRadius: 20,
    paddingVertical: 22,
    paddingHorizontal: 14,
    marginBottom: 20,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.07,
    shadowRadius: 12,
    elevation: 4,
  },
  iconContainer: { padding: 15, borderRadius: 15, marginBottom: 15 },
  cardTitle: { fontSize: 14, fontWeight: '600', color: Colors.text, textAlign: 'center' },
  adminButton: {
    margin: 20,
    marginTop: 10,
    backgroundColor: Colors.secondary,
    padding: 18,
    borderRadius: 15,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  adminButtonText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
  loginCta: { marginHorizontal: 20, marginBottom: 24, backgroundColor: '#fff', borderWidth: 1, borderColor: Colors.border, borderRadius: 14, padding: 14, alignItems: 'center' },
  loginCtaText: { color: Colors.primary, fontWeight: '700', fontSize: 13 },
});

export default Dashboard;
