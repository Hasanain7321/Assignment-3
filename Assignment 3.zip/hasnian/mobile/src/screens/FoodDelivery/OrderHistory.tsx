import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity, ActivityIndicator } from 'react-native';
import client from '../../api/client';
import { Colors } from '../../constants/Colors';
import { ChevronRight, Package } from 'lucide-react-native';

const OrderHistory = ({ navigation }: any) => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    try {
      const res = await client.get('/api/orders');
      setOrders(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color={Colors.primary} /></View>;

  return (
    <View style={styles.container}>
      <FlatList
        data={orders}
        keyExtractor={(item: any) => item._id}
        contentContainerStyle={{ padding: 20 }}
        renderItem={({ item }) => (
          <TouchableOpacity 
            style={styles.card}
            onPress={() => navigation.navigate('OrderDetails', { orderId: item._id })}
          >
            <View style={styles.iconBox}><Package color={Colors.primary} size={24} /></View>
            <View style={{ flex: 1, marginLeft: 15 }}>
              <Text style={styles.orderId}>{item.orderId}</Text>
              <Text style={styles.date}>{new Date(item.date).toLocaleDateString()}</Text>
            </View>
            <View style={{ alignItems: 'flex-end' }}>
              <Text style={styles.price}>${item.totalPrice.toFixed(2)}</Text>
              <ChevronRight size={20} color={Colors.border} />
            </View>
          </TouchableOpacity>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  card: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    backgroundColor: '#fff', 
    padding: 20, 
    borderRadius: 20, 
    marginBottom: 15,
    elevation: 2
  },
  iconBox: { width: 50, height: 50, borderRadius: 15, backgroundColor: '#EFF6FF', justifyContent: 'center', alignItems: 'center' },
  orderId: { fontSize: 16, fontWeight: 'bold', color: Colors.text },
  date: { fontSize: 12, color: Colors.secondary, marginTop: 4 },
  price: { fontSize: 16, fontWeight: 'bold', color: Colors.accent, marginBottom: 5 },
});

export default OrderHistory;
