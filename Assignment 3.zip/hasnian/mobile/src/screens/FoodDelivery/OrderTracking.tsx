import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { Colors } from '../../constants/Colors';
import { CheckCircle, Clock, Truck, Package, MapPin } from 'lucide-react-native';

const steps = [
  { label: 'Order Confirmed', icon: CheckCircle, time: 'Just now' },
  { label: 'Preparing', icon: Package, time: '~10 min' },
  { label: 'On the Way', icon: Truck, time: '~25 min' },
  { label: 'Delivered', icon: MapPin, time: '~40 min' },
];

const OrderTracking = ({ navigation }: any) => {
  const [currentStep, setCurrentStep] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentStep(prev => {
        if (prev < steps.length - 1) return prev + 1;
        clearInterval(interval);
        return prev;
      });
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Order Status</Text>
        <Text style={styles.headerSub}>Estimated delivery: 30-45 min</Text>
      </View>

      <View style={styles.trackingCard}>
        {steps.map((step, idx) => {
          const isActive = idx <= currentStep;
          const isCurrent = idx === currentStep;
          const IconComp = step.icon;
          return (
            <View key={idx} style={styles.stepRow}>
              <View style={styles.stepLeft}>
                <View style={[styles.stepCircle, isActive && styles.stepCircleActive, isCurrent && styles.stepCircleCurrent]}>
                  <IconComp size={18} color={isActive ? '#fff' : Colors.secondary} />
                </View>
                {idx < steps.length - 1 && <View style={[styles.stepLine, isActive && styles.stepLineActive]} />}
              </View>
              <View style={styles.stepInfo}>
                <Text style={[styles.stepLabel, isActive && styles.stepLabelActive]}>{step.label}</Text>
                <Text style={styles.stepTime}>{step.time}</Text>
                {isCurrent && (
                  <View style={styles.currentBadge}>
                    <View style={styles.dot} />
                    <Text style={styles.currentText}>In Progress</Text>
                  </View>
                )}
              </View>
            </View>
          );
        })}
      </View>

      <View style={styles.mapPlaceholder}>
        <MapPin size={40} color={Colors.secondary} />
        <Text style={styles.mapText}>Live tracking map</Text>
        <Text style={styles.mapSub}>Your rider is on the way!</Text>
      </View>

      <TouchableOpacity style={styles.doneBtn} onPress={() => navigation.popToTop()}>
        <Text style={styles.doneBtnText}>Back to Home</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: { backgroundColor: '#EF4444', padding: 25 },
  headerTitle: { color: '#fff', fontSize: 22, fontWeight: 'bold' },
  headerSub: { color: 'rgba(255,255,255,0.8)', fontSize: 14, marginTop: 4 },
  trackingCard: { backgroundColor: '#fff', margin: 15, borderRadius: 18, padding: 20, elevation: 3 },
  stepRow: { flexDirection: 'row', minHeight: 70 },
  stepLeft: { alignItems: 'center', width: 40 },
  stepCircle: { width: 36, height: 36, borderRadius: 18, backgroundColor: Colors.background, justifyContent: 'center', alignItems: 'center', borderWidth: 2, borderColor: Colors.border },
  stepCircleActive: { backgroundColor: Colors.accent, borderColor: Colors.accent },
  stepCircleCurrent: { backgroundColor: '#EF4444', borderColor: '#EF4444' },
  stepLine: { width: 2, flex: 1, backgroundColor: Colors.border, marginVertical: 4 },
  stepLineActive: { backgroundColor: Colors.accent },
  stepInfo: { flex: 1, marginLeft: 12, paddingBottom: 15 },
  stepLabel: { fontSize: 15, fontWeight: '600', color: Colors.secondary },
  stepLabelActive: { color: Colors.text },
  stepTime: { fontSize: 12, color: Colors.secondary, marginTop: 2 },
  currentBadge: { flexDirection: 'row', alignItems: 'center', marginTop: 6 },
  dot: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#EF4444', marginRight: 6 },
  currentText: { fontSize: 12, color: '#EF4444', fontWeight: '600' },
  mapPlaceholder: { backgroundColor: '#fff', margin: 15, borderRadius: 18, padding: 40, alignItems: 'center', elevation: 2, borderWidth: 1, borderColor: Colors.border, borderStyle: 'dashed' },
  mapText: { fontSize: 16, fontWeight: 'bold', color: Colors.secondary, marginTop: 10 },
  mapSub: { fontSize: 13, color: Colors.secondary, marginTop: 4 },
  doneBtn: { margin: 15, backgroundColor: Colors.primary, padding: 16, borderRadius: 14, alignItems: 'center' },
  doneBtnText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
});

export default OrderTracking;
