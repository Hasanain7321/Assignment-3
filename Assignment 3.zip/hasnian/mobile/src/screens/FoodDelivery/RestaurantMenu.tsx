import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, Image, StyleSheet, TouchableOpacity, ActivityIndicator, SectionList } from 'react-native';
import client from '../../api/client';
import { Colors } from '../../constants/Colors';
import { Plus, ShoppingBag } from 'lucide-react-native';
import { useFoodCart } from '../../context/FoodCartContext';

const RestaurantMenu = ({ route, navigation }: any) => {
  const { restaurantId, restaurantName } = route.params;
  const [menuItems, setMenuItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const { addItem, totalItems } = useFoodCart();

  useEffect(() => { fetchMenu(); }, []);

  const fetchMenu = async () => {
    try { const res = await client.get(`/api/restaurants/${restaurantId}/menu`); setMenuItems(res.data); }
    catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  const categories = [...new Set(menuItems.map(i => i.category))];
  const sections = categories.map(cat => ({ title: cat, data: menuItems.filter(i => i.category === cat) }));

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color={Colors.danger} /></View>;

  return (
    <View style={styles.container}>
      <SectionList
        sections={sections}
        keyExtractor={(item) => item._id}
        stickySectionHeadersEnabled={false}
        renderSectionHeader={({ section }) => <Text style={styles.sectionTitle}>{section.title}</Text>}
        contentContainerStyle={{ padding: 15 }}
        ListHeaderComponent={
          <View style={styles.header}>
            <Text style={styles.rName}>{restaurantName}</Text>
            <Text style={styles.menuLabel}>{menuItems.length} items on the menu</Text>
          </View>
        }
        renderItem={({ item }) => (
          <View style={styles.card}>
            <View style={styles.cardInfo}>
              {item.isPopular && <Text style={styles.popularBadge}>🔥 Popular</Text>}
              <Text style={styles.itemName}>{item.name}</Text>
              <Text style={styles.itemDesc} numberOfLines={2}>{item.description}</Text>
              <Text style={styles.itemPrice}>${item.price.toFixed(2)}</Text>
            </View>
            <View style={styles.cardRight}>
              <Image source={{ uri: item.image }} style={styles.itemImage} />
              <TouchableOpacity style={styles.addBtn} onPress={() => addItem(item, restaurantId, restaurantName)}>
                <Plus size={18} color="#fff" />
              </TouchableOpacity>
            </View>
          </View>
        )}
      />

      {totalItems > 0 && (
        <TouchableOpacity style={styles.cartBar} onPress={() => navigation.navigate('FoodCart')}>
          <View style={styles.cartLeft}>
            <ShoppingBag size={20} color="#fff" />
            <Text style={styles.cartText}>{totalItems} item(s) in cart</Text>
          </View>
          <Text style={styles.cartAction}>View Cart →</Text>
        </TouchableOpacity>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { marginBottom: 15 },
  rName: { fontSize: 22, fontWeight: 'bold', color: Colors.text },
  menuLabel: { fontSize: 13, color: Colors.secondary, marginTop: 2 },
  sectionTitle: { fontSize: 16, fontWeight: 'bold', color: Colors.text, marginTop: 15, marginBottom: 10, backgroundColor: '#fff', paddingVertical: 5 },
  card: { flexDirection: 'row', backgroundColor: '#fff', borderRadius: 14, marginBottom: 12, borderWidth: 1, borderColor: Colors.border, overflow: 'hidden' },
  cardInfo: { flex: 1, padding: 12 },
  popularBadge: { fontSize: 11, color: '#B45309', backgroundColor: '#FEF3C7', alignSelf: 'flex-start', paddingHorizontal: 8, paddingVertical: 2, borderRadius: 6, overflow: 'hidden', marginBottom: 4 },
  itemName: { fontSize: 15, fontWeight: 'bold', color: Colors.text },
  itemDesc: { fontSize: 12, color: Colors.secondary, marginTop: 3, lineHeight: 18 },
  itemPrice: { fontSize: 15, fontWeight: 'bold', color: Colors.accent, marginTop: 6 },
  cardRight: { width: 100, alignItems: 'center', justifyContent: 'center' },
  itemImage: { width: 90, height: 80, borderRadius: 10, backgroundColor: Colors.background },
  addBtn: { position: 'absolute', bottom: 5, right: 5, backgroundColor: Colors.danger, width: 30, height: 30, borderRadius: 15, justifyContent: 'center', alignItems: 'center' },
  cartBar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: Colors.danger, padding: 16, margin: 12, borderRadius: 14 },
  cartLeft: { flexDirection: 'row', alignItems: 'center' },
  cartText: { color: '#fff', fontWeight: 'bold', fontSize: 15, marginLeft: 10 },
  cartAction: { color: '#fff', fontWeight: 'bold', fontSize: 14 },
});

export default RestaurantMenu;
