import React from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { Colors } from '../../constants/Colors';
import { useFoodCart } from '../../context/FoodCartContext';
import { Trash2, Plus, Minus, ShoppingBag } from 'lucide-react-native';
import client from '../../api/client';
import { useAuth } from '../../context/AuthContext';

const FoodCart = ({ navigation }: any) => {
  const { items, restaurantName, removeItem, updateQuantity, totalPrice, clearCart } = useFoodCart();
  const { user } = useAuth();

  if (items.length === 0) {
    return (
      <View style={styles.empty}>
        <ShoppingBag size={60} color={Colors.border} />
        <Text style={styles.emptyTitle}>Your food cart is empty</Text>
        <Text style={styles.emptySub}>Browse restaurants and add items</Text>
      </View>
    );
  }

  const deliveryFee = 2.99;
  const grandTotal = totalPrice + deliveryFee;

  const handleOrder = async () => {
    if (!user) {
      Alert.alert('Sign in required', 'Please sign in from My Profile before placing food orders.', [
        { text: 'Go to My Profile', onPress: () => navigation.navigate('AccountProfile') },
        { text: 'Cancel', style: 'cancel' },
      ]);
      return;
    }
    try {
      await client.post('/api/orders', {
        totalPrice: grandTotal,
        status: 'Preparing',
        items: items.map(i => ({ name: i.name, quantity: i.quantity, price: i.price })),
        restaurantName: restaurantName,
        deliveryAddress: '123 Main Street',
        estimatedTime: '30-45 min',
      });
      Alert.alert('Order Placed! 🎉', 'Your food is being prepared.', [
        { text: 'Track Order', onPress: () => { clearCart(); navigation.navigate('OrderTracking'); } },
      ]);
    } catch (err) {
      Alert.alert('Ordered!', 'Your food is on its way!', [
        { text: 'OK', onPress: () => { clearCart(); navigation.popToTop(); } },
      ]);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.restaurantHeader}>
        <Text style={styles.from}>Order from</Text>
        <Text style={styles.rName}>{restaurantName}</Text>
      </View>

      <FlatList
        data={items}
        keyExtractor={(item) => item._id}
        contentContainerStyle={{ padding: 15 }}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <View style={styles.info}>
              <Text style={styles.name}>{item.name}</Text>
              <Text style={styles.price}>${item.price.toFixed(2)}</Text>
            </View>
            <View style={styles.qtyRow}>
              <TouchableOpacity style={styles.qtyBtn} onPress={() => updateQuantity(item._id, item.quantity - 1)}>
                <Minus size={14} color={Colors.text} />
              </TouchableOpacity>
              <Text style={styles.qty}>{item.quantity}</Text>
              <TouchableOpacity style={styles.qtyBtn} onPress={() => updateQuantity(item._id, item.quantity + 1)}>
                <Plus size={14} color={Colors.text} />
              </TouchableOpacity>
            </View>
            <TouchableOpacity onPress={() => removeItem(item._id)}><Trash2 size={16} color={Colors.danger} /></TouchableOpacity>
          </View>
        )}
      />

      <View style={styles.summary}>
        <View style={styles.sRow}><Text style={styles.sLabel}>Subtotal</Text><Text style={styles.sVal}>${totalPrice.toFixed(2)}</Text></View>
        <View style={styles.sRow}><Text style={styles.sLabel}>Delivery Fee</Text><Text style={styles.sVal}>${deliveryFee.toFixed(2)}</Text></View>
        <View style={styles.divider} />
        <View style={styles.sRow}><Text style={styles.totalLabel}>Total</Text><Text style={styles.totalVal}>${grandTotal.toFixed(2)}</Text></View>
        <TouchableOpacity style={styles.orderBtn} onPress={handleOrder}>
          <Text style={styles.orderBtnText}>Place Order • ${grandTotal.toFixed(2)}</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  empty: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 40 },
  emptyTitle: { fontSize: 20, fontWeight: 'bold', color: Colors.text, marginTop: 15 },
  emptySub: { fontSize: 14, color: Colors.secondary, marginTop: 6 },
  restaurantHeader: { padding: 20, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: Colors.border },
  from: { fontSize: 12, color: Colors.secondary },
  rName: { fontSize: 18, fontWeight: 'bold', color: Colors.text },
  card: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', padding: 14, borderRadius: 14, marginBottom: 8, elevation: 1 },
  info: { flex: 1 },
  name: { fontSize: 15, fontWeight: 'bold', color: Colors.text },
  price: { fontSize: 13, color: Colors.accent, marginTop: 2 },
  qtyRow: { flexDirection: 'row', alignItems: 'center', marginRight: 12 },
  qtyBtn: { width: 26, height: 26, borderRadius: 8, backgroundColor: Colors.background, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: Colors.border },
  qty: { marginHorizontal: 10, fontWeight: 'bold', fontSize: 14 },
  summary: { backgroundColor: '#fff', padding: 20, borderTopLeftRadius: 20, borderTopRightRadius: 20, elevation: 8 },
  sRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 },
  sLabel: { fontSize: 14, color: Colors.secondary },
  sVal: { fontSize: 14, color: Colors.text },
  divider: { height: 1, backgroundColor: Colors.border, marginVertical: 8 },
  totalLabel: { fontSize: 17, fontWeight: 'bold' },
  totalVal: { fontSize: 17, fontWeight: 'bold', color: Colors.accent },
  orderBtn: { backgroundColor: '#EF4444', padding: 16, borderRadius: 14, alignItems: 'center', marginTop: 14 },
  orderBtnText: { color: '#fff', fontSize: 17, fontWeight: 'bold' },
});

export default FoodCart;
