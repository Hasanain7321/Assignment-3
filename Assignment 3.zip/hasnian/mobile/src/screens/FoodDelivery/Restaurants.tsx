import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, StyleSheet, Image, TouchableOpacity, ScrollView } from 'react-native';
import client from '../../api/client';
import { Colors } from '../../constants/Colors';
import { Star, Clock, DollarSign, History, ShoppingBag } from 'lucide-react-native';
import { useFoodCart } from '../../context/FoodCartContext';

const cuisines = ['All', 'Thai', 'American', 'Japanese', 'Italian', 'Pakistani', 'Chinese'];

const Restaurants = ({ navigation }: any) => {
  const [restaurants, setRestaurants] = useState([]);
  const [selectedCuisine, setSelectedCuisine] = useState('All');
  const { totalItems } = useFoodCart();

  useEffect(() => { fetchRestaurants(); }, []);

  const fetchRestaurants = async () => {
    try { const res = await client.get('/api/restaurants'); setRestaurants(res.data); }
    catch (err) { console.error(err); }
  };

  const filteredData = selectedCuisine === 'All' ? restaurants : restaurants.filter((r: any) => r.cuisine === selectedCuisine);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View>
          <Text style={styles.deliver}>Deliver to</Text>
          <Text style={styles.title}>123 Main Street 📍</Text>
        </View>
        <View style={styles.headerIcons}>
          <TouchableOpacity style={styles.iconBtn} onPress={() => navigation.navigate('FoodCart')}>
            <ShoppingBag size={22} color={Colors.primary} />
            {totalItems > 0 && <View style={styles.badge}><Text style={styles.badgeText}>{totalItems}</Text></View>}
          </TouchableOpacity>
          <TouchableOpacity style={styles.iconBtn} onPress={() => navigation.navigate('OrderHistory')}>
            <History size={22} color={Colors.primary} />
          </TouchableOpacity>
        </View>
      </View>

      <View style={{ height: 50 }}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filterBar}>
          {cuisines.map(c => (
            <TouchableOpacity key={c} style={[styles.filterChip, selectedCuisine === c && styles.activeChip]} onPress={() => setSelectedCuisine(c)}>
              <Text style={[styles.filterText, selectedCuisine === c && { color: '#fff' }]}>{c}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      <FlatList
        data={filteredData}
        keyExtractor={(item: any) => item._id}
        contentContainerStyle={{ padding: 15 }}
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.card} onPress={() => navigation.navigate('RestaurantMenu', { restaurantId: item._id, restaurantName: item.name })}>
            <Image source={{ uri: item.image }} style={styles.image} />
            <View style={styles.cardOverlay}>
              <View style={styles.deliveryBadge}><Clock size={12} color="#fff" /><Text style={styles.deliveryText}>{item.deliveryTime}</Text></View>
            </View>
            <View style={styles.info}>
              <View style={styles.row}>
                <Text style={styles.rName}>{item.name}</Text>
                <View style={styles.ratingRow}><Star size={13} color="#F59E0B" fill="#F59E0B" /><Text style={styles.ratingText}>{item.rating}</Text></View>
              </View>
              <Text style={styles.cuisine}>{item.cuisine} Cuisine</Text>
              <View style={styles.metaRow}>
                <Text style={styles.meta}>Min. ${item.minOrder}</Text>
                <Text style={styles.meta}>• Delivery ${item.deliveryFee}</Text>
                {!item.isOpen && <Text style={styles.closed}>CLOSED</Text>}
              </View>
            </View>
          </TouchableOpacity>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 20, paddingBottom: 10 },
  deliver: { fontSize: 12, color: Colors.secondary },
  title: { fontSize: 18, fontWeight: 'bold', color: Colors.text },
  headerIcons: { flexDirection: 'row' },
  iconBtn: { marginLeft: 10, width: 42, height: 42, borderRadius: 12, backgroundColor: '#F1F5F9', justifyContent: 'center', alignItems: 'center' },
  badge: { position: 'absolute', top: -4, right: -4, backgroundColor: Colors.danger, borderRadius: 10, width: 18, height: 18, justifyContent: 'center', alignItems: 'center' },
  badgeText: { color: '#fff', fontSize: 10, fontWeight: 'bold' },
  filterBar: { paddingHorizontal: 15, alignItems: 'center' },
  filterChip: { paddingHorizontal: 16, paddingVertical: 8, backgroundColor: '#F1F5F9', borderRadius: 20, marginRight: 8, borderWidth: 1, borderColor: '#E2E8F0' },
  activeChip: { backgroundColor: '#EF4444', borderColor: '#EF4444' },
  filterText: { color: Colors.secondary, fontWeight: '600', fontSize: 13 },
  card: { backgroundColor: '#fff', borderRadius: 18, marginBottom: 20, overflow: 'hidden', elevation: 4 },
  image: { width: '100%', height: 170 },
  cardOverlay: { position: 'absolute', top: 12, right: 12 },
  deliveryBadge: { flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(0,0,0,0.65)', paddingHorizontal: 10, paddingVertical: 5, borderRadius: 8 },
  deliveryText: { color: '#fff', fontSize: 12, fontWeight: '600', marginLeft: 4 },
  info: { padding: 14 },
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  rName: { fontSize: 17, fontWeight: 'bold', color: Colors.text },
  ratingRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#FEF3C7', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8 },
  ratingText: { marginLeft: 4, fontSize: 12, fontWeight: 'bold', color: '#B45309' },
  cuisine: { fontSize: 13, color: Colors.secondary, marginTop: 3 },
  metaRow: { flexDirection: 'row', marginTop: 6, alignItems: 'center' },
  meta: { fontSize: 12, color: Colors.secondary },
  closed: { fontSize: 11, color: Colors.danger, fontWeight: 'bold', marginLeft: 8, backgroundColor: '#FEF2F2', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 4, overflow: 'hidden' },
});

export default Restaurants;
