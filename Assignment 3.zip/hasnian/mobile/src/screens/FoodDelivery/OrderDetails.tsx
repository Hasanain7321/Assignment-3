import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, ActivityIndicator } from 'react-native';
import client from '../../api/client';
import { Colors } from '../../constants/Colors';

const OrderDetails = ({ route }: any) => {
  const { orderId } = route.params;
  const [order, setOrder] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchOrder();
  }, []);

  const fetchOrder = async () => {
    try {
      const res = await client.get(`/api/orders/${orderId}`);
      setOrder(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color={Colors.primary} /></View>;
  if (!order) return null;

  return (
    <ScrollView style={styles.container}>
      <View style={styles.statusBanner}>
        <Text style={styles.statusText}>Status: {order.status}</Text>
      </View>
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Order Summary</Text>
        <Text style={styles.orderId}>ID: {order.orderId}</Text>
        <Text style={styles.date}>Placed on {new Date(order.date).toLocaleString()}</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Items</Text>
        {order.items.map((item: any, idx: number) => (
          <View key={idx} style={styles.itemRow}>
            <Text style={styles.itemName}>{item.quantity}x {item.name}</Text>
            <Text style={styles.itemPrice}>${(item.price * item.quantity).toFixed(2)}</Text>
          </View>
        ))}
        <View style={styles.divider} />
        <View style={styles.row}>
          <Text style={styles.totalLabel}>Total Paid</Text>
          <Text style={styles.totalPrice}>${order.totalPrice.toFixed(2)}</Text>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  statusBanner: { backgroundColor: Colors.primary, padding: 20, alignItems: 'center' },
  statusText: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
  section: { backgroundColor: '#fff', margin: 20, padding: 20, borderRadius: 20, elevation: 1 },
  sectionTitle: { fontSize: 14, fontWeight: 'bold', color: Colors.secondary, textTransform: 'uppercase', marginBottom: 15 },
  orderId: { fontSize: 18, fontWeight: 'bold', color: Colors.text },
  date: { color: Colors.secondary, marginTop: 5 },
  itemRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 },
  itemName: { fontSize: 16, color: Colors.text },
  itemPrice: { fontSize: 16, fontWeight: '600' },
  divider: { height: 1, backgroundColor: Colors.border, marginVertical: 15 },
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  totalLabel: { fontSize: 18, fontWeight: 'bold' },
  totalPrice: { fontSize: 22, fontWeight: 'bold', color: Colors.accent },
});

export default OrderDetails;
