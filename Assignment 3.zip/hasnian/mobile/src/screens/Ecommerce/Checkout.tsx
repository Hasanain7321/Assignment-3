import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView, Alert } from 'react-native';
import { Colors } from '../../constants/Colors';
import { useCart } from '../../context/CartContext';
import { CheckCircle2 } from 'lucide-react-native';
import { useAuth } from '../../context/AuthContext';

const Checkout = ({ navigation }: any) => {
  const { items, totalPrice, clearCart } = useCart();
  const { user } = useAuth();
  const [form, setForm] = useState({ name: '', address: '', city: '', phone: '' });
  const tax = totalPrice * 0.05;
  const shipping = totalPrice > 100 ? 0 : 9.99;
  const grandTotal = totalPrice + tax + shipping;

  const handleOrder = () => {
    if (!user) {
      Alert.alert('Sign in required', 'Please sign in from My Profile before placing an order.', [
        { text: 'Go to My Profile', onPress: () => navigation.navigate('AccountProfile') },
        { text: 'Cancel', style: 'cancel' },
      ]);
      return;
    }
    if (!form.name || !form.address || !form.phone) {
      Alert.alert('Missing Info', 'Please fill all required fields.');
      return;
    }
    Alert.alert('Order Placed! 🎉', `Your order of $${grandTotal.toFixed(2)} has been placed successfully!`, [
      { text: 'OK', onPress: () => { clearCart(); navigation.popToTop(); } }
    ]);
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.heading}>Shipping Information</Text>
      <TextInput style={styles.input} placeholder="Full Name *" value={form.name} onChangeText={v => setForm({ ...form, name: v })} />
      <TextInput style={styles.input} placeholder="Address *" value={form.address} onChangeText={v => setForm({ ...form, address: v })} />
      <TextInput style={styles.input} placeholder="City" value={form.city} onChangeText={v => setForm({ ...form, city: v })} />
      <TextInput style={styles.input} placeholder="Phone *" keyboardType="phone-pad" value={form.phone} onChangeText={v => setForm({ ...form, phone: v })} />

      <Text style={styles.heading}>Order Summary</Text>
      <View style={styles.card}>
        {items.map(item => (
          <View key={item._id} style={styles.itemRow}>
            <Text style={styles.itemName}>{item.quantity}x {item.name}</Text>
            <Text style={styles.itemPrice}>${(item.price * item.quantity).toFixed(2)}</Text>
          </View>
        ))}
        <View style={styles.divider} />
        <View style={styles.itemRow}><Text style={styles.label}>Subtotal</Text><Text style={styles.val}>${totalPrice.toFixed(2)}</Text></View>
        <View style={styles.itemRow}><Text style={styles.label}>Tax (5%)</Text><Text style={styles.val}>${tax.toFixed(2)}</Text></View>
        <View style={styles.itemRow}><Text style={styles.label}>Shipping</Text><Text style={styles.val}>{shipping === 0 ? 'FREE' : `$${shipping.toFixed(2)}`}</Text></View>
        <View style={styles.divider} />
        <View style={styles.itemRow}><Text style={styles.totalLabel}>Total</Text><Text style={styles.totalVal}>${grandTotal.toFixed(2)}</Text></View>
      </View>

      <TouchableOpacity style={styles.orderBtn} onPress={handleOrder}>
        <CheckCircle2 size={20} color="#fff" style={{ marginRight: 10 }} />
        <Text style={styles.orderBtnText}>Place Order</Text>
      </TouchableOpacity>
      <View style={{ height: 40 }} />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background, padding: 20 },
  heading: { fontSize: 18, fontWeight: 'bold', color: Colors.text, marginBottom: 15, marginTop: 10 },
  input: { backgroundColor: '#fff', borderWidth: 1, borderColor: Colors.border, borderRadius: 12, padding: 14, fontSize: 15, marginBottom: 12 },
  card: { backgroundColor: '#fff', borderRadius: 16, padding: 18, elevation: 2 },
  itemRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  itemName: { fontSize: 14, color: Colors.text, flex: 1 },
  itemPrice: { fontSize: 14, fontWeight: '600', color: Colors.text },
  divider: { height: 1, backgroundColor: Colors.border, marginVertical: 10 },
  label: { fontSize: 14, color: Colors.secondary },
  val: { fontSize: 14, color: Colors.text },
  totalLabel: { fontSize: 17, fontWeight: 'bold', color: Colors.text },
  totalVal: { fontSize: 17, fontWeight: 'bold', color: Colors.accent },
  orderBtn: { backgroundColor: Colors.accent, padding: 18, borderRadius: 14, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginTop: 20 },
  orderBtnText: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
});

export default Checkout;
