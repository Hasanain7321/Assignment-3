import React from 'react';
import { View, Text, FlatList, Image, StyleSheet, TouchableOpacity } from 'react-native';
import { Colors } from '../../constants/Colors';
import { useCart } from '../../context/CartContext';
import { Trash2, Plus, Minus, ShoppingBag } from 'lucide-react-native';

const Cart = ({ navigation }: any) => {
  const { items, removeItem, updateQuantity, totalPrice, clearCart } = useCart();

  if (items.length === 0) {
    return (
      <View style={styles.empty}>
        <ShoppingBag size={64} color={Colors.border} />
        <Text style={styles.emptyTitle}>Your cart is empty</Text>
        <Text style={styles.emptySubtitle}>Browse products and add items to your cart</Text>
        <TouchableOpacity style={styles.shopBtn} onPress={() => navigation.navigate('Ecommerce')}>
          <Text style={styles.shopBtnText}>Start Shopping</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const tax = totalPrice * 0.05;
  const grandTotal = totalPrice + tax;

  return (
    <View style={styles.container}>
      <FlatList
        data={items}
        keyExtractor={(item) => item._id}
        contentContainerStyle={{ padding: 15 }}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Image source={{ uri: item.image }} style={styles.image} />
            <View style={styles.info}>
              <Text style={styles.name} numberOfLines={1}>{item.name}</Text>
              <Text style={styles.price}>${item.price.toFixed(2)}</Text>
              <View style={styles.qtyRow}>
                <TouchableOpacity style={styles.qtyBtn} onPress={() => updateQuantity(item._id, item.quantity - 1)}>
                  <Minus size={16} color={Colors.text} />
                </TouchableOpacity>
                <Text style={styles.qty}>{item.quantity}</Text>
                <TouchableOpacity style={styles.qtyBtn} onPress={() => updateQuantity(item._id, item.quantity + 1)}>
                  <Plus size={16} color={Colors.text} />
                </TouchableOpacity>
              </View>
            </View>
            <TouchableOpacity onPress={() => removeItem(item._id)} style={styles.deleteBtn}>
              <Trash2 size={18} color={Colors.danger} />
            </TouchableOpacity>
          </View>
        )}
      />

      <View style={styles.summary}>
        <View style={styles.summaryRow}><Text style={styles.label}>Subtotal</Text><Text style={styles.val}>${totalPrice.toFixed(2)}</Text></View>
        <View style={styles.summaryRow}><Text style={styles.label}>Tax (5%)</Text><Text style={styles.val}>${tax.toFixed(2)}</Text></View>
        <View style={styles.divider} />
        <View style={styles.summaryRow}><Text style={styles.totalLabel}>Total</Text><Text style={styles.totalVal}>${grandTotal.toFixed(2)}</Text></View>
        <TouchableOpacity style={styles.checkoutBtn} onPress={() => navigation.navigate('Checkout')}>
          <Text style={styles.checkoutText}>Proceed to Checkout</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  empty: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 40 },
  emptyTitle: { fontSize: 22, fontWeight: 'bold', color: Colors.text, marginTop: 20 },
  emptySubtitle: { fontSize: 14, color: Colors.secondary, marginTop: 8, textAlign: 'center' },
  shopBtn: { marginTop: 25, backgroundColor: Colors.primary, paddingHorizontal: 30, paddingVertical: 14, borderRadius: 12 },
  shopBtnText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  card: { flexDirection: 'row', backgroundColor: '#fff', borderRadius: 16, padding: 12, marginBottom: 10, alignItems: 'center', elevation: 2 },
  image: { width: 70, height: 70, borderRadius: 12 },
  info: { flex: 1, marginLeft: 12 },
  name: { fontSize: 15, fontWeight: 'bold', color: Colors.text },
  price: { fontSize: 14, color: Colors.accent, fontWeight: '600', marginTop: 2 },
  qtyRow: { flexDirection: 'row', alignItems: 'center', marginTop: 6 },
  qtyBtn: { width: 28, height: 28, borderRadius: 8, backgroundColor: Colors.background, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: Colors.border },
  qty: { marginHorizontal: 12, fontSize: 15, fontWeight: 'bold' },
  deleteBtn: { padding: 8 },
  summary: { backgroundColor: '#fff', padding: 20, borderTopLeftRadius: 25, borderTopRightRadius: 25, elevation: 8 },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  label: { fontSize: 14, color: Colors.secondary },
  val: { fontSize: 14, color: Colors.text },
  divider: { height: 1, backgroundColor: Colors.border, marginVertical: 10 },
  totalLabel: { fontSize: 18, fontWeight: 'bold', color: Colors.text },
  totalVal: { fontSize: 18, fontWeight: 'bold', color: Colors.accent },
  checkoutBtn: { backgroundColor: Colors.primary, padding: 16, borderRadius: 14, alignItems: 'center', marginTop: 15 },
  checkoutText: { color: '#fff', fontSize: 17, fontWeight: 'bold' },
});

export default Cart;
