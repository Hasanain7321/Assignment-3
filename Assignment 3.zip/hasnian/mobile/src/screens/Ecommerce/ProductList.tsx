import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, Image, StyleSheet, TouchableOpacity, ActivityIndicator, TextInput, ScrollView } from 'react-native';
import client from '../../api/client';
import { Colors } from '../../constants/Colors';
import { Search, ShoppingCart } from 'lucide-react-native';
import { useCart } from '../../context/CartContext';

const categories = ['All', 'Electronics', 'Gaming', 'Fashion', 'Sports', 'Home'];

const ProductList = ({ navigation }: any) => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedCat, setSelectedCat] = useState('All');
  const { totalItems } = useCart();

  useEffect(() => { fetchProducts(); }, []);

  const fetchProducts = async () => {
    try {
      const res = await client.get('/api/products');
      setProducts(res.data);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  const filtered = products.filter((p: any) => {
    const matchCat = selectedCat === 'All' || p.category === selectedCat;
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color={Colors.primary} /></View>;

  return (
    <View style={styles.container}>
      <View style={styles.searchRow}>
        <View style={styles.searchBox}>
          <Search size={18} color={Colors.secondary} />
          <TextInput placeholder="Search products..." style={styles.searchInput} value={search} onChangeText={setSearch} />
        </View>
        <TouchableOpacity style={styles.cartBtn} onPress={() => navigation.navigate('Cart')}>
          <ShoppingCart size={22} color={Colors.primary} />
          {totalItems > 0 && <View style={styles.badge}><Text style={styles.badgeText}>{totalItems}</Text></View>}
        </TouchableOpacity>
      </View>

      <View style={{ height: 50 }}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.catBar}>
          {categories.map(c => (
            <TouchableOpacity key={c} style={[styles.catChip, selectedCat === c && styles.catActive]} onPress={() => setSelectedCat(c)}>
              <Text style={[styles.catText, selectedCat === c && { color: '#fff' }]}>{c}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      <FlatList
        data={filtered}
        keyExtractor={(item: any) => item._id}
        numColumns={2}
        contentContainerStyle={{ padding: 10 }}
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.card} onPress={() => navigation.navigate('ProductDetails', { id: item._id })}>
            <Image source={{ uri: item.image }} style={styles.image} />
            <View style={styles.info}>
              <Text style={styles.brand}>{item.brand}</Text>
              <Text style={styles.name} numberOfLines={1}>{item.name}</Text>
              <View style={styles.priceRow}>
                <Text style={styles.price}>${item.price.toFixed(2)}</Text>
                <Text style={styles.rating}>⭐ {item.rating}</Text>
              </View>
            </View>
          </TouchableOpacity>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  searchRow: { flexDirection: 'row', alignItems: 'center', padding: 15, paddingBottom: 5 },
  searchBox: { flex: 1, flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', borderRadius: 12, paddingHorizontal: 12, height: 44, borderWidth: 1, borderColor: Colors.border },
  searchInput: { flex: 1, marginLeft: 8, fontSize: 15 },
  cartBtn: { marginLeft: 12, width: 44, height: 44, borderRadius: 12, backgroundColor: '#fff', justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: Colors.border },
  badge: { position: 'absolute', top: -4, right: -4, backgroundColor: Colors.danger, borderRadius: 10, width: 20, height: 20, justifyContent: 'center', alignItems: 'center' },
  badgeText: { color: '#fff', fontSize: 11, fontWeight: 'bold' },
  catBar: { paddingHorizontal: 15, alignItems: 'center' },
  catChip: { paddingHorizontal: 16, paddingVertical: 8, backgroundColor: '#fff', borderRadius: 20, marginRight: 8, borderWidth: 1, borderColor: Colors.border },
  catActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  catText: { color: Colors.secondary, fontWeight: '600', fontSize: 13 },
  card: { flex: 1, backgroundColor: '#fff', margin: 6, borderRadius: 16, overflow: 'hidden', elevation: 3 },
  image: { width: '100%', height: 140 },
  info: { padding: 10 },
  brand: { fontSize: 11, color: Colors.secondary, textTransform: 'uppercase', letterSpacing: 1 },
  name: { fontSize: 14, fontWeight: 'bold', color: Colors.text, marginTop: 2 },
  priceRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 6 },
  price: { fontSize: 16, color: Colors.accent, fontWeight: 'bold' },
  rating: { fontSize: 12, color: Colors.secondary },
});

export default ProductList;
