import React, { useEffect, useState } from 'react';
import { View, Text, Image, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator, Alert, FlatList } from 'react-native';
import client from '../../api/client';
import { Colors } from '../../constants/Colors';
import { ShoppingCart, Star, ChevronRight } from 'lucide-react-native';
import { useCart } from '../../context/CartContext';

const ProductDetails = ({ route, navigation }: any) => {
  const { id } = route.params;
  const [product, setProduct] = useState<any>(null);
  const [reviews, setReviews] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const { addItem } = useCart();

  useEffect(() => { fetchDetail(); fetchReviews(); }, []);

  const fetchDetail = async () => {
    try { const res = await client.get(`/api/products/${id}`); setProduct(res.data); }
    catch (err) { Alert.alert('Error', 'Could not load details'); }
    finally { setLoading(false); }
  };

  const fetchReviews = async () => {
    try { const res = await client.get(`/api/products/${id}/reviews`); setReviews(res.data); }
    catch (err) { console.error(err); }
  };

  const handleAddToCart = () => {
    addItem(product);
    Alert.alert('Added!', `${product.name} added to cart`, [
      { text: 'Continue Shopping', style: 'cancel' },
      { text: 'Go to Cart', onPress: () => navigation.navigate('Cart') },
    ]);
  };

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color={Colors.primary} /></View>;
  if (!product) return null;

  return (
    <ScrollView style={styles.container}>
      <Image source={{ uri: product.image }} style={styles.image} />
      <View style={styles.content}>
        <Text style={styles.brand}>{product.brand}</Text>
        <Text style={styles.title}>{product.name}</Text>
        <View style={styles.ratingRow}>
          <View style={styles.ratingBadge}>
            <Star size={14} color="#F59E0B" fill="#F59E0B" />
            <Text style={styles.ratingText}>{product.rating}</Text>
          </View>
          <Text style={styles.reviewCount}>{product.reviewCount} reviews</Text>
          <Text style={[styles.stockBadge, !product.inStock && { backgroundColor: '#FEF2F2', color: Colors.danger }]}>
            {product.inStock ? 'In Stock' : 'Out of Stock'}
          </Text>
        </View>
        <Text style={styles.price}>${product.price.toFixed(2)}</Text>
        <Text style={styles.description}>{product.description}</Text>

        <TouchableOpacity style={styles.button} onPress={handleAddToCart}>
          <ShoppingCart size={20} color="#fff" style={{ marginRight: 10 }} />
          <Text style={styles.buttonText}>Add to Cart</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.checkoutLink} onPress={() => { handleAddToCart(); navigation.navigate('Checkout'); }}>
          <Text style={styles.checkoutText}>Buy Now</Text>
          <ChevronRight size={18} color={Colors.primary} />
        </TouchableOpacity>

        {reviews.length > 0 && (
          <View style={styles.reviewSection}>
            <Text style={styles.sectionTitle}>Customer Reviews</Text>
            {reviews.slice(0, 5).map((r: any, idx: number) => (
              <View key={idx} style={styles.reviewCard}>
                <View style={styles.reviewHeader}>
                  <Text style={styles.reviewerName}>{r.userName}</Text>
                  <Text style={styles.reviewRating}>{'⭐'.repeat(r.rating)}</Text>
                </View>
                <Text style={styles.reviewComment}>{r.comment}</Text>
                <Text style={styles.reviewDate}>{new Date(r.date).toLocaleDateString()}</Text>
              </View>
            ))}
          </View>
        )}
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  image: { width: '100%', height: 320 },
  content: { padding: 20 },
  brand: { fontSize: 12, color: Colors.secondary, textTransform: 'uppercase', letterSpacing: 2 },
  title: { fontSize: 24, fontWeight: 'bold', color: Colors.text, marginTop: 4 },
  ratingRow: { flexDirection: 'row', alignItems: 'center', marginTop: 10, flexWrap: 'wrap' },
  ratingBadge: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#FEF3C7', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8 },
  ratingText: { marginLeft: 4, fontSize: 13, fontWeight: 'bold', color: '#B45309' },
  reviewCount: { marginLeft: 10, fontSize: 13, color: Colors.secondary },
  stockBadge: { marginLeft: 10, fontSize: 12, backgroundColor: '#ECFDF5', color: Colors.accent, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6, overflow: 'hidden', fontWeight: '600' },
  price: { fontSize: 28, color: Colors.accent, fontWeight: 'bold', marginTop: 15 },
  description: { fontSize: 15, color: Colors.textSecondary, lineHeight: 24, marginTop: 10, marginBottom: 25 },
  button: { backgroundColor: Colors.primary, padding: 16, borderRadius: 14, flexDirection: 'row', justifyContent: 'center', alignItems: 'center' },
  buttonText: { color: '#fff', fontSize: 17, fontWeight: 'bold' },
  checkoutLink: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginTop: 12, padding: 14, borderRadius: 14, borderWidth: 1.5, borderColor: Colors.primary },
  checkoutText: { color: Colors.primary, fontSize: 17, fontWeight: 'bold' },
  reviewSection: { marginTop: 30 },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', color: Colors.text, marginBottom: 15 },
  reviewCard: { backgroundColor: Colors.background, padding: 15, borderRadius: 12, marginBottom: 10 },
  reviewHeader: { flexDirection: 'row', justifyContent: 'space-between' },
  reviewerName: { fontSize: 14, fontWeight: 'bold', color: Colors.text },
  reviewRating: { fontSize: 12 },
  reviewComment: { fontSize: 14, color: Colors.textSecondary, marginTop: 6 },
  reviewDate: { fontSize: 11, color: Colors.secondary, marginTop: 6 },
});

export default ProductDetails;
