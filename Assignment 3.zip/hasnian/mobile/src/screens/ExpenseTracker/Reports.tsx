import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Dimensions, ScrollView, ActivityIndicator } from 'react-native';
import { BarChart } from "react-native-chart-kit";
import client from '../../api/client';
import { Colors } from '../../constants/Colors';

const Reports = () => {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const res = await client.get('/api/transactions');
      const transactions = res.data;

      // Logic to group by month for the chart
      const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      const monthlyData: any = {};

      transactions.forEach((t: any) => {
        if (t.category === 'expense') {
          const month = months[new Date(t.date).getMonth()];
          monthlyData[month] = (monthlyData[month] || 0) + t.amount;
        }
      });

      // We only want the last 6 months or months with data
      const labels = months.filter(m => monthlyData[m] !== undefined);
      const dataset = labels.map(m => monthlyData[m]);

      if (labels.length === 0) {
        // Fallback for empty data
        setData({ labels: ['None'], datasets: [{ data: [0] }] });
      } else {
        setData({
          labels,
          datasets: [{ data: dataset }]
        });
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color={Colors.primary} /></View>;

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Monthly Spending Trend</Text>
      
      {data && (
        <View style={styles.chartContainer}>
           <Text style={styles.chartTitle}>Expense Overview ($)</Text>
           <BarChart
            data={data}
            width={Dimensions.get("window").width - 40}
            height={220}
            yAxisLabel="$"
            yAxisSuffix=""
            chartConfig={{
                backgroundColor: "#fff",
                backgroundGradientFrom: "#fff",
                backgroundGradientTo: "#fff",
                decimalPlaces: 0,
                color: (opacity = 1) => `rgba(30, 58, 138, ${opacity})`, // primary navy
                labelColor: (opacity = 1) => `rgba(100, 116, 139, ${opacity})`,
                style: { borderRadius: 16 },
                propsForDots: {
                  r: "6",
                  strokeWidth: "2",
                  stroke: Colors.primary
                }
              }}
              verticalLabelRotation={30}
              style={{
                marginVertical: 8,
                borderRadius: 16
              }}
           />
        </View>
      )}

      <View style={styles.infoCard}>
         <Text style={styles.infoTitle}>Analysis</Text>
         <Text style={styles.infoBody}>
           This report fetches all transactions marked as expense from your local database and aggregates them by month to visualize your spending habits.
         </Text>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background, padding: 20 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  title: { fontSize: 22, fontWeight: 'bold', color: Colors.text, marginBottom: 20 },
  chartContainer: { backgroundColor: '#fff', padding: 15, borderRadius: 20, elevation: 2 },
  chartTitle: { fontSize: 16, fontWeight: '600', color: Colors.secondary, marginBottom: 10 },
  infoCard: { backgroundColor: Colors.primary, padding: 25, borderRadius: 20, marginTop: 25 },
  infoTitle: { color: '#fff', fontSize: 18, fontWeight: 'bold', marginBottom: 10 },
  infoBody: { color: 'rgba(255,255,255,0.8)', fontSize: 14, lineHeight: 22 },
});

export default Reports;
