import React, { useEffect, useState, useCallback } from 'react';
import { View, Text, StyleSheet, FlatList, ActivityIndicator, TouchableOpacity } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import client from '../../api/client';
import { Colors } from '../../constants/Colors';
import { TrendingUp, TrendingDown, PieChart, Plus, Trash2 } from 'lucide-react-native';

const ExpensesDashboard = ({ navigation }: any) => {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchTransactions = async () => {
    try { const res = await client.get('/api/transactions'); setTransactions(res.data); }
    catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  useFocusEffect(useCallback(() => { fetchTransactions(); }, []));

  const handleDelete = async (id: string) => {
    try {
      await client.delete(`/api/transactions/${id}`);
      setTransactions(prev => prev.filter((t: any) => t._id !== id));
    } catch (err) { console.error(err); }
  };

  const totals = transactions.reduce((acc: any, curr: any) => {
    if (curr.category === 'income') acc.income += curr.amount;
    else acc.expense += curr.amount;
    acc.balance = acc.income - acc.expense;
    return acc;
  }, { income: 0, expense: 0, balance: 0 });

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color={Colors.primary} /></View>;

  return (
    <View style={styles.container}>
      <View style={styles.summaryContainer}>
        <View style={styles.summaryBox}>
          <Text style={styles.summaryLabel}>Total Balance</Text>
          <Text style={styles.balanceText}>Rs. {totals.balance.toLocaleString()}</Text>
          <View style={styles.btnRow}>
            <TouchableOpacity style={styles.reportBtn} onPress={() => navigation.navigate('Reports')}>
              <PieChart size={14} color="#fff" style={{ marginRight: 6 }} />
              <Text style={styles.reportBtnText}>Reports</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.addBtn} onPress={() => navigation.navigate('AddTransaction')}>
              <Plus size={14} color="#fff" style={{ marginRight: 6 }} />
              <Text style={styles.reportBtnText}>Add New</Text>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.row}>
          <View style={[styles.miniBox, { backgroundColor: '#ECFDF5' }]}>
            <TrendingUp size={20} color="#10B981" />
            <Text style={styles.miniLabel}>Income</Text>
            <Text style={[styles.miniVal, { color: '#10B981' }]}>+Rs. {totals.income.toLocaleString()}</Text>
          </View>
          <View style={[styles.miniBox, { backgroundColor: '#FEF2F2' }]}>
            <TrendingDown size={20} color="#EF4444" />
            <Text style={styles.miniLabel}>Expenses</Text>
            <Text style={[styles.miniVal, { color: '#EF4444' }]}>-Rs. {totals.expense.toLocaleString()}</Text>
          </View>
        </View>
      </View>

      <Text style={styles.sectionTitle}>Recent Transactions</Text>
      <FlatList
        data={transactions}
        keyExtractor={(item: any) => item._id}
        contentContainerStyle={{ padding: 20, paddingTop: 0 }}
        renderItem={({ item }) => (
          <View style={styles.transactionCard}>
            <View style={[styles.iconCircle, { backgroundColor: item.category === 'income' ? '#ECFDF5' : '#FEF2F2' }]}>
              {item.category === 'income' ? <TrendingUp size={18} color="#10B981" /> : <TrendingDown size={18} color="#EF4444" />}
            </View>
            <View style={{ flex: 1, marginLeft: 12 }}>
              <Text style={styles.tLabel}>{item.label || item.category}</Text>
              <Text style={styles.tNote} numberOfLines={1}>{item.note || ''}</Text>
              <Text style={styles.tDate}>{new Date(item.date).toLocaleDateString()}</Text>
            </View>
            <View style={{ alignItems: 'flex-end' }}>
              <Text style={[styles.tAmount, { color: item.category === 'income' ? '#10B981' : '#EF4444' }]}>
                {item.category === 'income' ? '+' : '-'}Rs. {item.amount.toLocaleString()}
              </Text>
              <TouchableOpacity onPress={() => handleDelete(item._id)} style={{ marginTop: 4 }}>
                <Trash2 size={14} color={Colors.secondary} />
              </TouchableOpacity>
            </View>
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  summaryContainer: { padding: 20 },
  summaryBox: { backgroundColor: Colors.primary, borderRadius: 25, padding: 25, alignItems: 'center', elevation: 8 },
  summaryLabel: { color: '#e0e0e0', fontSize: 14 },
  balanceText: { color: '#fff', fontSize: 36, fontWeight: 'bold', marginVertical: 8 },
  btnRow: { flexDirection: 'row', marginTop: 5 },
  reportBtn: { flexDirection: 'row', backgroundColor: 'rgba(255,255,255,0.2)', paddingVertical: 8, paddingHorizontal: 14, borderRadius: 20, marginHorizontal: 5, alignItems: 'center' },
  addBtn: { flexDirection: 'row', backgroundColor: Colors.accent, paddingVertical: 8, paddingHorizontal: 14, borderRadius: 20, marginHorizontal: 5, alignItems: 'center' },
  reportBtnText: { color: '#fff', fontWeight: '600', fontSize: 13 },
  row: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 15 },
  miniBox: { width: '48%', borderRadius: 18, padding: 18 },
  miniLabel: { fontSize: 12, color: Colors.secondary, marginVertical: 4 },
  miniVal: { fontSize: 16, fontWeight: 'bold' },
  sectionTitle: { fontSize: 17, fontWeight: 'bold', color: Colors.text, marginLeft: 20, marginBottom: 10 },
  transactionCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', padding: 14, borderRadius: 14, marginBottom: 8, elevation: 1 },
  iconCircle: { width: 42, height: 42, borderRadius: 21, justifyContent: 'center', alignItems: 'center' },
  tLabel: { fontSize: 14, fontWeight: 'bold', color: Colors.text },
  tNote: { fontSize: 12, color: Colors.secondary, marginTop: 1 },
  tDate: { fontSize: 11, color: Colors.secondary, marginTop: 2 },
  tAmount: { fontSize: 15, fontWeight: 'bold' },
});

export default ExpensesDashboard;
