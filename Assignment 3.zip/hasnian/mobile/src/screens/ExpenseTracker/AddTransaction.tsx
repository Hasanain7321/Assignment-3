import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView, Alert } from 'react-native';
import client from '../../api/client';
import { Colors } from '../../constants/Colors';
import { Plus, Check } from 'lucide-react-native';

const expenseLabels = ['Groceries', 'Rent', 'Transport', 'Food', 'Shopping', 'Entertainment', 'Health', 'Utilities', 'Education', 'Other'];
const incomeLabels = ['Salary', 'Freelance', 'Investment', 'Gift', 'Other'];

const AddTransaction = ({ navigation }: any) => {
  const [type, setType] = useState<'income' | 'expense'>('expense');
  const [amount, setAmount] = useState('');
  const [selectedLabel, setSelectedLabel] = useState('');
  const [note, setNote] = useState('');

  const labels = type === 'expense' ? expenseLabels : incomeLabels;

  const handleAdd = async () => {
    if (!amount || !selectedLabel) { Alert.alert('Missing', 'Please enter amount and select a category.'); return; }
    try {
      await client.post('/api/transactions', { amount: parseFloat(amount), category: type, label: selectedLabel, note, date: new Date() });
      Alert.alert('Added!', 'Transaction recorded successfully.', [{ text: 'OK', onPress: () => navigation.goBack() }]);
    } catch (err) { Alert.alert('Error', 'Could not add transaction.'); }
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.heading}>Add Transaction</Text>

      <View style={styles.typeRow}>
        <TouchableOpacity style={[styles.typeBtn, type === 'expense' && styles.expenseActive]} onPress={() => { setType('expense'); setSelectedLabel(''); }}>
          <Text style={[styles.typeText, type === 'expense' && { color: '#fff' }]}>Expense</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.typeBtn, type === 'income' && styles.incomeActive]} onPress={() => { setType('income'); setSelectedLabel(''); }}>
          <Text style={[styles.typeText, type === 'income' && { color: '#fff' }]}>Income</Text>
        </TouchableOpacity>
      </View>

      <Text style={styles.label}>Amount</Text>
      <TextInput style={styles.amountInput} placeholder="0.00" keyboardType="numeric" value={amount} onChangeText={setAmount} />

      <Text style={styles.label}>Category</Text>
      <View style={styles.labelsWrap}>
        {labels.map(l => (
          <TouchableOpacity key={l} style={[styles.labelChip, selectedLabel === l && (type === 'expense' ? styles.chipExpense : styles.chipIncome)]} onPress={() => setSelectedLabel(l)}>
            <Text style={[styles.labelChipText, selectedLabel === l && { color: '#fff' }]}>{l}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <Text style={styles.label}>Note (optional)</Text>
      <TextInput style={styles.noteInput} placeholder="Add a note..." value={note} onChangeText={setNote} multiline />

      <TouchableOpacity style={[styles.addBtn, type === 'income' ? { backgroundColor: Colors.accent } : { backgroundColor: Colors.danger }]} onPress={handleAdd}>
        <Check size={18} color="#fff" style={{ marginRight: 8 }} />
        <Text style={styles.addBtnText}>Add {type === 'income' ? 'Income' : 'Expense'}</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff', padding: 20 },
  heading: { fontSize: 24, fontWeight: 'bold', color: Colors.text, marginBottom: 20 },
  typeRow: { flexDirection: 'row', marginBottom: 20 },
  typeBtn: { flex: 1, padding: 14, borderRadius: 12, alignItems: 'center', backgroundColor: Colors.background, marginHorizontal: 4, borderWidth: 1, borderColor: Colors.border },
  expenseActive: { backgroundColor: Colors.danger, borderColor: Colors.danger },
  incomeActive: { backgroundColor: Colors.accent, borderColor: Colors.accent },
  typeText: { fontWeight: 'bold', fontSize: 15, color: Colors.secondary },
  label: { fontSize: 14, fontWeight: '600', color: Colors.secondary, marginBottom: 8, marginTop: 10 },
  amountInput: { backgroundColor: Colors.background, borderRadius: 12, padding: 16, fontSize: 24, fontWeight: 'bold', textAlign: 'center', borderWidth: 1, borderColor: Colors.border },
  labelsWrap: { flexDirection: 'row', flexWrap: 'wrap' },
  labelChip: { paddingHorizontal: 14, paddingVertical: 8, backgroundColor: Colors.background, borderRadius: 20, marginRight: 8, marginBottom: 8, borderWidth: 1, borderColor: Colors.border },
  chipExpense: { backgroundColor: Colors.danger, borderColor: Colors.danger },
  chipIncome: { backgroundColor: Colors.accent, borderColor: Colors.accent },
  labelChipText: { fontSize: 13, fontWeight: '600', color: Colors.secondary },
  noteInput: { backgroundColor: Colors.background, borderRadius: 12, padding: 14, fontSize: 14, minHeight: 80, borderWidth: 1, borderColor: Colors.border, textAlignVertical: 'top' },
  addBtn: { padding: 16, borderRadius: 14, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginTop: 25 },
  addBtnText: { color: '#fff', fontSize: 17, fontWeight: 'bold' },
});

export default AddTransaction;
