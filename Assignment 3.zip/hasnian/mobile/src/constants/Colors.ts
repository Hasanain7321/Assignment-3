export const Colors = {
  primary: '#1E3A8A', // Deep Navy
  secondary: '#64748B', // Slate Gray
  accent: '#10B981', // Emerald for success/calls to action
  danger: '#EF4444', // Red for errors/deletions
  background: '#F8FAFC', // Light background
  surface: '#FFFFFF', // White for cards
  text: '#0F172A', // Dark text
  textSecondary: '#475569', // Muted text
  border: '#E2E8F0', // Border color
};
