import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import client, { setAuthToken } from '../api/client';

type User = {
  _id: string;
  name: string;
  email: string;
  username: string;
  phone?: string;
  bio?: string;
  avatar?: string;
};

type AuthContextValue = {
  user: User | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (payload: { name: string; username: string; email: string; password: string }) => Promise<void>;
  signOut: () => Promise<void>;
  updateProfile: (payload: Partial<User>) => Promise<void>;
};

const AuthContext = createContext<AuthContextValue | undefined>(undefined);
const TOKEN_KEY = 'superapp_token';

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const restore = async () => {
      try {
        const token = await AsyncStorage.getItem(TOKEN_KEY);
        if (!token) return;
        setAuthToken(token);
        const me = await client.get('/api/auth/me');
        setUser(me.data.user);
      } catch {
        await AsyncStorage.removeItem(TOKEN_KEY);
        setAuthToken(null);
      } finally {
        setLoading(false);
      }
    };
    restore();
  }, []);

  const signIn = async (email: string, password: string) => {
    const res = await client.post('/api/auth/signin', { email, password });
    const { token, user: profile } = res.data;
    await AsyncStorage.setItem(TOKEN_KEY, token);
    setAuthToken(token);
    setUser(profile);
  };

  const signUp = async (payload: { name: string; username: string; email: string; password: string }) => {
    const res = await client.post('/api/auth/signup', payload);
    const { token, user: profile } = res.data;
    await AsyncStorage.setItem(TOKEN_KEY, token);
    setAuthToken(token);
    setUser(profile);
  };

  const signOut = async () => {
    await AsyncStorage.removeItem(TOKEN_KEY);
    setAuthToken(null);
    setUser(null);
  };

  const updateProfile = async (payload: Partial<User>) => {
    const res = await client.put('/api/auth/profile', payload);
    setUser(res.data.user);
  };

  const value = useMemo(() => ({ user, loading, signIn, signUp, signOut, updateProfile }), [user, loading]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
};
