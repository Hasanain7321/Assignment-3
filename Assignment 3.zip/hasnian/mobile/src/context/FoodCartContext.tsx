import React, { createContext, useContext, useState, ReactNode } from 'react';

type FoodCartItem = {
  _id: string;
  name: string;
  price: number;
  image: string;
  quantity: number;
  restaurantId: string;
};

type FoodCartContextType = {
  items: FoodCartItem[];
  restaurantId: string | null;
  restaurantName: string | null;
  addItem: (item: any, rId: string, rName: string) => void;
  removeItem: (id: string) => void;
  updateQuantity: (id: string, qty: number) => void;
  clearCart: () => void;
  totalItems: number;
  totalPrice: number;
};

const FoodCartContext = createContext<FoodCartContextType>({} as FoodCartContextType);

export const useFoodCart = () => useContext(FoodCartContext);

export const FoodCartProvider = ({ children }: { children: ReactNode }) => {
  const [items, setItems] = useState<FoodCartItem[]>([]);
  const [restaurantId, setRestaurantId] = useState<string | null>(null);
  const [restaurantName, setRestaurantName] = useState<string | null>(null);

  const addItem = (item: any, rId: string, rName: string) => {
    if (restaurantId && restaurantId !== rId) {
      setItems([]);
    }
    setRestaurantId(rId);
    setRestaurantName(rName);
    setItems(prev => {
      const exists = prev.find(i => i._id === item._id);
      if (exists) {
        return prev.map(i => i._id === item._id ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, { _id: item._id, name: item.name, price: item.price, image: item.image || '', quantity: 1, restaurantId: rId }];
    });
  };

  const removeItem = (id: string) => {
    const next = items.filter(i => i._id !== id);
    setItems(next);
    if (next.length === 0) { setRestaurantId(null); setRestaurantName(null); }
  };

  const updateQuantity = (id: string, qty: number) => {
    if (qty <= 0) return removeItem(id);
    setItems(prev => prev.map(i => i._id === id ? { ...i, quantity: qty } : i));
  };

  const clearCart = () => { setItems([]); setRestaurantId(null); setRestaurantName(null); };

  const totalItems = items.reduce((s, i) => s + i.quantity, 0);
  const totalPrice = items.reduce((s, i) => s + i.price * i.quantity, 0);

  return (
    <FoodCartContext.Provider value={{ items, restaurantId, restaurantName, addItem, removeItem, updateQuantity, clearCart, totalItems, totalPrice }}>
      {children}
    </FoodCartContext.Provider>
  );
};
