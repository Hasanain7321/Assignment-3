import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';

const THEME_KEY = 'superapp_theme_mode';

export const lightTheme = {
  primary: '#1E3A8A',
  secondary: '#64748B',
  accent: '#10B981',
  danger: '#EF4444',
  background: '#F8FAFC',
  surface: '#FFFFFF',
  text: '#0F172A',
  textSecondary: '#475569',
  border: '#E2E8F0',
};

export const darkTheme = {
  primary: '#0F172A',
  secondary: '#94A3B8',
  accent: '#22C55E',
  danger: '#F87171',
  background: '#020617',
  surface: '#111827',
  text: '#F8FAFC',
  textSecondary: '#94A3B8',
  border: '#1F2937',
};

type ThemeContextValue = {
  isDark: boolean;
  colors: typeof lightTheme;
  toggleTheme: () => Promise<void>;
};

const ThemeContext = createContext<ThemeContextValue | undefined>(undefined);

export const ThemeProvider = ({ children }: { children: React.ReactNode }) => {
  const [isDark, setIsDark] = useState(false);

  useEffect(() => {
    const loadTheme = async () => {
      const mode = await AsyncStorage.getItem(THEME_KEY);
      setIsDark(mode === 'dark');
    };
    loadTheme();
  }, []);

  const toggleTheme = useCallback(async () => {
    const next = !isDark;
    setIsDark(next);
    await AsyncStorage.setItem(THEME_KEY, next ? 'dark' : 'light');
  }, [isDark]);

  const value = useMemo(
    () => ({ isDark, colors: isDark ? darkTheme : lightTheme, toggleTheme }),
    [isDark, toggleTheme]
  );

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
};

export const useTheme = () => {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error('useTheme must be used within ThemeProvider');
  return ctx;
};
