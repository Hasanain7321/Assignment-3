import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { ArrowLeft } from 'lucide-react-native';
import { useTheme } from '../context/ThemeContext';

const AppHeader = ({ navigation, route, options, back }: any) => {
  const [time, setTime] = useState(new Date());
  const { colors } = useTheme();
  const isDashboard = route.name === 'Dashboard';
  const title = options?.title || route.name;

  useEffect(() => {
    const id = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  return (
    <View style={[styles.header, { backgroundColor: colors.primary, borderBottomColor: colors.border }]}>
      <View style={styles.left}>
        {back && !isDashboard ? (
          <TouchableOpacity onPress={navigation.goBack} style={[styles.backBtn, { borderColor: isDashboard ? 'transparent' : 'rgba(255,255,255,0.35)' }]}>
            <ArrowLeft color="#fff" size={18} />
          </TouchableOpacity>
        ) : (
          <View style={styles.backPlaceholder} />
        )}
        <Text style={styles.title}>{title}</Text>
      </View>
      {!isDashboard ? <Text style={styles.time}>{time.toLocaleTimeString()}</Text> : <View style={styles.backPlaceholder} />}
    </View>
  );
};

const styles = StyleSheet.create({
  header: { paddingHorizontal: 14, height: 64, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderBottomWidth: 1 },
  left: { flexDirection: 'row', alignItems: 'center', flex: 1 },
  backBtn: { width: 32, height: 32, borderRadius: 16, borderWidth: 1, borderColor: 'rgba(255,255,255,0.4)', justifyContent: 'center', alignItems: 'center', marginRight: 10 },
  backPlaceholder: { width: 32, height: 32, marginRight: 10 },
  title: { color: '#fff', fontWeight: '700', fontSize: 16 },
  time: { color: '#fff', fontVariant: ['tabular-nums'], fontSize: 12 },
});

export default AppHeader;
