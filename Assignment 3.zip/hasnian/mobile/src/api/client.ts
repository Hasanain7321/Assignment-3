import axios from 'axios';
import { Platform } from 'react-native';
import Constants from 'expo-constants';

const expoHost = Constants.expoConfig?.hostUri?.split(':')?.[0];
const isAndroidEmulator = Platform.OS === 'android' && !expoHost;
const fallbackHost = isAndroidEmulator ? '10.0.2.2' : 'localhost';
const host = expoHost || fallbackHost;
const BASE_URL = process.env.EXPO_PUBLIC_API_URL || `http://${host}:3000`;

const client = axios.create({
  baseURL: BASE_URL,
  timeout: 10000,
});

export const setAuthToken = (token: string | null) => {
  if (token) {
    client.defaults.headers.common.Authorization = `Bearer ${token}`;
  } else {
    delete client.defaults.headers.common.Authorization;
  }
};

export default client;
