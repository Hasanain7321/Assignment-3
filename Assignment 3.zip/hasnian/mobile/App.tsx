import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StatusBar } from 'expo-status-bar';
import { ActivityIndicator, View } from 'react-native';
import { CartProvider } from './src/context/CartContext';
import { FoodCartProvider } from './src/context/FoodCartContext';
import { AuthProvider, useAuth } from './src/context/AuthContext';
import { ThemeProvider, useTheme } from './src/context/ThemeContext';

// Screens
import Dashboard from './src/screens/Dashboard';
import SignIn from './src/screens/Auth/SignIn';
import SignUp from './src/screens/Auth/SignUp';
import AccountProfile from './src/screens/AccountProfile';
import ProductList from './src/screens/Ecommerce/ProductList';
import ProductDetails from './src/screens/Ecommerce/ProductDetails';
import Cart from './src/screens/Ecommerce/Cart';
import Checkout from './src/screens/Ecommerce/Checkout';
import Feed from './src/screens/SocialMedia/Feed';
import PostDetails from './src/screens/SocialMedia/PostDetails';
import Profile from './src/screens/SocialMedia/Profile';
import CreatePost from './src/screens/SocialMedia/CreatePost';
import Comments from './src/screens/SocialMedia/Comments';
import Events from './src/screens/TicketBooking/Events';
import SeatSelection from './src/screens/TicketBooking/SeatSelection';
import TicketSummary from './src/screens/TicketBooking/TicketSummary';
import ExpensesDashboard from './src/screens/ExpenseTracker/ExpensesDashboard';
import AddTransaction from './src/screens/ExpenseTracker/AddTransaction';
import Reports from './src/screens/ExpenseTracker/Reports';
import Restaurants from './src/screens/FoodDelivery/Restaurants';
import RestaurantMenu from './src/screens/FoodDelivery/RestaurantMenu';
import FoodCart from './src/screens/FoodDelivery/FoodCart';
import OrderHistory from './src/screens/FoodDelivery/OrderHistory';
import OrderDetails from './src/screens/FoodDelivery/OrderDetails';
import OrderTracking from './src/screens/FoodDelivery/OrderTracking';

import AppHeader from './src/components/AppHeader';

const Stack = createNativeStackNavigator();

const RootNavigator = () => {
  const { loading } = useAuth();
  const { isDark, colors } = useTheme();
  if (loading) {
    return <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: colors.background }}><ActivityIndicator size="large" color={colors.primary} /></View>;
  }

  return (
    <NavigationContainer theme={{ dark: isDark, colors: { primary: colors.primary, background: colors.background, card: colors.surface, text: colors.text, border: colors.border, notification: colors.accent } }}>
      <StatusBar style={isDark ? 'light' : 'dark'} />
      <Stack.Navigator
        initialRouteName="Dashboard"
        screenOptions={{
          header: (props) => <AppHeader {...props} />,
          contentStyle: { backgroundColor: colors.background },
        }}
      >
        <Stack.Screen name="Dashboard" component={Dashboard} options={{ headerShown: false }} />
        <Stack.Screen name="SignIn" component={SignIn} options={{ title: 'Sign In' }} />
        <Stack.Screen name="SignUp" component={SignUp} options={{ title: 'Sign Up' }} />
        <Stack.Screen name="AccountProfile" component={AccountProfile} options={{ title: 'My Profile' }} />

        {/* E-Commerce */}
        <Stack.Screen name="Ecommerce" component={ProductList} options={{ title: 'Shop' }} />
        <Stack.Screen name="ProductDetails" component={ProductDetails} options={{ title: 'Product' }} />
        <Stack.Screen name="Cart" component={Cart} options={{ title: 'My Cart' }} />
        <Stack.Screen name="Checkout" component={Checkout} options={{ title: 'Checkout' }} />

        {/* Social Media */}
        <Stack.Screen name="SocialMedia" component={Feed} options={{ title: 'Social Media' }} />
        <Stack.Screen name="PostDetails" component={PostDetails} options={{ title: 'Post' }} />
        <Stack.Screen name="Profile" component={Profile} options={{ title: 'Profile' }} />
        <Stack.Screen name="CreatePost" component={CreatePost} options={{ title: 'New Post' }} />
        <Stack.Screen name="Comments" component={Comments} options={{ title: 'Comments' }} />

        {/* Ticket Booking */}
        <Stack.Screen name="TicketBooking" component={Events} options={{ title: 'Events & Tickets' }} />
        <Stack.Screen name="SeatSelection" component={SeatSelection} options={{ title: 'Select Seats' }} />
        <Stack.Screen name="TicketSummary" component={TicketSummary} options={{ title: 'Booking Confirmed' }} />

        {/* Expense Tracker */}
        <Stack.Screen name="ExpenseTracker" component={ExpensesDashboard} options={{ title: 'My Finances' }} />
        <Stack.Screen name="AddTransaction" component={AddTransaction} options={{ title: 'Add Transaction' }} />
        <Stack.Screen name="Reports" component={Reports} options={{ title: 'Reports' }} />

        {/* Food Delivery */}
        <Stack.Screen name="FoodDelivery" component={Restaurants} options={{ title: 'Food Delivery' }} />
        <Stack.Screen name="RestaurantMenu" component={RestaurantMenu} options={{ title: 'Menu' }} />
        <Stack.Screen name="FoodCart" component={FoodCart} options={{ title: 'Your Order' }} />
        <Stack.Screen name="OrderHistory" component={OrderHistory} options={{ title: 'Order History' }} />
        <Stack.Screen name="OrderDetails" component={OrderDetails} options={{ title: 'Order Details' }} />
        <Stack.Screen name="OrderTracking" component={OrderTracking} options={{ headerShown: false }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <CartProvider>
          <FoodCartProvider>
            <RootNavigator />
          </FoodCartProvider>
        </CartProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}
