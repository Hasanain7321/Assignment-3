module.exports = {
  products: [
    { _id: '1', name: 'Wireless Headphones', price: 199.99, image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500&q=80', description: 'High-quality noise-canceling headphones.' },
    { _id: '2', name: 'Smartwatch Series 5', price: 299.00, image: 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=500&q=80', description: 'Stay connected on the go.' },
  ],
  posts: [
    { _id: '1', title: 'Hello World', body: 'This is my first post on this amazing social media app!', userId: { name: 'John Doe' } },
    { _id: '2', title: 'React Native is cool', body: 'Just learned how to use React Navigation.', userId: { name: 'Jane Smith' } },
  ],
  events: [
    { _id: '1', title: 'Avengers Marathon', poster: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=500&q=80', releaseDate: '2026-05-01' },
  ],
  transactions: [
    { _id: '1', amount: 2500, category: 'income', date: '2026-04-01' },
    { _id: '2', amount: 50, category: 'expense', date: '2026-04-03' },
  ],
  restaurants: [
    { _id: '1', name: 'Spicy Thai', cuisine: 'Thai', rating: 4.8, image: 'https://images.unsplash.com/photo-1559314809-0d155014e29e?w=500&q=80' },
  ],
  orders: [
    { _id: '1', orderId: 'ORD-001', date: '2026-04-10', totalPrice: 45.99, status: 'Delivered' },
  ]
};
