const { Product, Review, User, Post, Comment, Event, Seat, Transaction, Restaurant, MenuItem, Order } = require('./models');

const generateRandomData = async () => {
  await Promise.all([
    Product.deleteMany({}), Review.deleteMany({}), User.deleteMany({}),
    Post.deleteMany({}), Comment.deleteMany({}), Event.deleteMany({}),
    Seat.deleteMany({}), Transaction.deleteMany({}), Restaurant.deleteMany({}),
    MenuItem.deleteMany({}), Order.deleteMany({}),
  ]);

  // ========== E-COMMERCE PRODUCTS ==========
  const products = await Product.insertMany([
    { name: 'Wireless Headphones', price: 199.99, image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500&q=80', description: 'Premium noise-canceling over-ear headphones with 30hr battery life.', category: 'Electronics', rating: 4.7, reviewCount: 128, brand: 'SoundMax' },
    { name: 'Smartwatch Series 5', price: 299.00, image: 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=500&q=80', description: 'Track your fitness, receive notifications, and more.', category: 'Electronics', rating: 4.5, reviewCount: 95, brand: 'TechFit' },
    { name: 'Gaming Mouse', price: 59.99, image: 'https://images.unsplash.com/photo-1527814050087-379381547996?w=500&q=80', description: 'Precision 16000 DPI optical sensor with RGB lighting.', category: 'Gaming', rating: 4.8, reviewCount: 210, brand: 'RazerX' },
    { name: 'Mechanical Keyboard', price: 129.50, image: 'https://images.unsplash.com/photo-1595225476474-87563907a212?w=500&q=80', description: 'Cherry MX switches with full RGB backlighting.', category: 'Gaming', rating: 4.6, reviewCount: 175, brand: 'KeyMaster' },
    { name: 'Running Shoes', price: 89.99, image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500&q=80', description: 'Lightweight breathable running shoes with cushioned sole.', category: 'Fashion', rating: 4.4, reviewCount: 67, brand: 'NikeFlex' },
    { name: 'Leather Backpack', price: 149.00, image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=500&q=80', description: 'Genuine leather backpack with laptop compartment.', category: 'Fashion', rating: 4.3, reviewCount: 42, brand: 'UrbanPack' },
    { name: 'Bluetooth Speaker', price: 79.99, image: 'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=500&q=80', description: 'Portable waterproof speaker with 360° sound.', category: 'Electronics', rating: 4.6, reviewCount: 156, brand: 'BoomBox' },
    { name: 'Yoga Mat', price: 34.99, image: 'https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f?w=500&q=80', description: 'Non-slip eco-friendly yoga mat, 6mm thick.', category: 'Sports', rating: 4.2, reviewCount: 89, brand: 'ZenFit' },
    { name: 'Coffee Maker', price: 199.99, image: 'https://images.unsplash.com/photo-1517668808822-9ebb02f2a0e6?w=500&q=80', description: 'Automatic drip coffee maker with thermal carafe.', category: 'Home', rating: 4.5, reviewCount: 112, brand: 'BrewMaster' },
    { name: 'Desk Lamp', price: 45.00, image: 'https://images.unsplash.com/photo-1507473885765-e6ed057ab6fe?w=500&q=80', description: 'LED desk lamp with adjustable brightness and color temperature.', category: 'Home', rating: 4.1, reviewCount: 53, brand: 'LumiGlow' },
  ]);

  // Reviews
  const reviewNames = ['Ali Khan', 'Sara Ahmed', 'Usman Malik', 'Hira Shah', 'Zain Raza'];
  const reviewComments = ['Amazing product!', 'Worth every penny.', 'Good quality.', 'Fast shipping.', 'Highly recommend!'];
  const reviews = [];
  for (const p of products) {
    for (let i = 0; i < 3; i++) {
      reviews.push({ productId: p._id, userName: reviewNames[i], rating: 4 + Math.round(Math.random()), comment: reviewComments[i], date: new Date(2026, 3, i + 1) });
    }
  }
  await Review.insertMany(reviews);

  // ========== SOCIAL MEDIA ==========
  const users = await User.insertMany([
    { name: 'John Doe', email: 'john@example.com', phone: '123-456-7890', username: 'johndoe', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&q=80', bio: 'Photographer & traveler', followers: 1240, following: 320, postsCount: 15 },
    { name: 'Jane Smith', email: 'jane@example.com', phone: '098-765-4321', username: 'janesmith', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&q=80', bio: 'Designer | Coffee lover', followers: 3450, following: 210, postsCount: 23 },
    { name: 'Ahmed Ali', email: 'ahmed@example.com', phone: '555-123-4567', username: 'ahmedali', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&q=80', bio: 'Tech enthusiast', followers: 890, following: 150, postsCount: 8 },
  ]);

  const postImages = [
    'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=600&q=80',
    'https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=600&q=80',
    'https://images.unsplash.com/photo-1501785888041-af3ef285b470?w=600&q=80',
    'https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=600&q=80',
    'https://images.unsplash.com/photo-1504893524553-b855bce32c67?w=600&q=80',
    'https://images.unsplash.com/photo-1519681393784-d120267933ba?w=600&q=80',
    'https://images.unsplash.com/photo-1530789253388-582c481c54b0?w=600&q=80',
    'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&q=80',
  ];

  const posts = await Post.insertMany([
    { title: 'Mountain Sunrise', body: 'Nothing beats waking up to this view! #nature #travel', image: postImages[0], userId: users[0]._id, likes: 342, commentsCount: 28 },
    { title: 'Golden Hour', body: 'The perfect light for photography 📸', image: postImages[1], userId: users[1]._id, likes: 567, commentsCount: 45 },
    { title: 'Lake Reflection', body: 'Peaceful morning at the lake #serenity', image: postImages[2], userId: users[0]._id, likes: 234, commentsCount: 19 },
    { title: 'Adventure Awaits', body: 'New adventures on the horizon!', image: postImages[3], userId: users[2]._id, likes: 189, commentsCount: 12 },
    { title: 'Waterfall Magic', body: 'Found this hidden gem today', image: postImages[4], userId: users[1]._id, likes: 445, commentsCount: 33 },
    { title: 'Starry Night', body: 'Clear skies and a million stars ✨', image: postImages[5], userId: users[0]._id, likes: 678, commentsCount: 56 },
    { title: 'Island Life', body: 'Living the dream on this beautiful island', image: postImages[6], userId: users[2]._id, likes: 321, commentsCount: 22 },
    { title: 'Beach Vibes', body: 'Sun, sand, and surf 🌊', image: postImages[7], userId: users[1]._id, likes: 512, commentsCount: 41 },
  ]);

  const commentTexts = ['Beautiful shot! 😍', 'Where is this?', 'Amazing!', 'Goals! 🔥', 'Love this!', 'Need to visit!'];
  const comments = [];
  for (const p of posts) {
    for (let i = 0; i < 3; i++) {
      const u = users[i % users.length];
      comments.push({ postId: p._id, userName: u.name, userAvatar: u.avatar, text: commentTexts[i % commentTexts.length] });
    }
  }
  await Comment.insertMany(comments);

  // ========== TICKET BOOKING ==========
  const events = await Event.insertMany([
    { title: 'Avengers: Secret Wars', poster: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=500&q=80', releaseDate: new Date('2026-05-01'), category: 'Movie', venue: 'Cinepax Ocean Mall', duration: '2h 45m', description: 'The epic conclusion to the Multiverse saga.', language: 'English' },
    { title: 'Tech Conference 2026', poster: 'https://images.unsplash.com/photo-1505373877841-8d25f7d46678?w=500&q=80', releaseDate: new Date('2026-06-15'), category: 'Conference', venue: 'Expo Center Karachi', duration: '8h', description: 'Annual tech conference featuring top speakers.', language: 'English' },
    { title: 'PSL Final 2026', poster: 'https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?w=500&q=80', releaseDate: new Date('2026-03-25'), category: 'Sports', venue: 'National Stadium Karachi', duration: '4h', description: 'The grand finale of Pakistan Super League.', language: 'Urdu' },
    { title: 'Atif Aslam Live', poster: 'https://images.unsplash.com/photo-1459749411175-04bf5292ceea?w=500&q=80', releaseDate: new Date('2026-07-10'), category: 'Concert', venue: 'Bahria Auditorium', duration: '3h', description: 'Live concert by the legendary Atif Aslam.', language: 'Urdu' },
    { title: 'The Batman 2', poster: 'https://images.unsplash.com/photo-1509347528160-9a9e33742cdb?w=500&q=80', releaseDate: new Date('2026-08-20'), category: 'Movie', venue: 'Nueplex DHA', duration: '2h 30m', description: 'The Dark Knight returns in an all-new thriller.', language: 'English' },
  ]);

  for (const ev of events) {
    const seats = [];
    const rows = ['A', 'B', 'C', 'D', 'E'];
    for (const r of rows) {
      for (let i = 1; i <= 8; i++) {
        const isVIP = r === 'A' || r === 'B';
        seats.push({ eventId: ev._id, seatNumber: `${r}${i}`, isBooked: Math.random() > 0.7, seatClass: isVIP ? 'VIP' : 'Standard', price: isVIP ? 1500 : 800 });
      }
    }
    await Seat.insertMany(seats);
  }

  // ========== EXPENSE TRACKER ==========
  await Transaction.insertMany([
    { amount: 85000, category: 'income', label: 'Salary', note: 'Monthly salary April', date: new Date('2026-04-01') },
    { amount: 5500, category: 'expense', label: 'Groceries', note: 'Weekly grocery shopping', date: new Date('2026-04-03') },
    { amount: 12000, category: 'expense', label: 'Rent', note: 'Monthly rent', date: new Date('2026-04-05') },
    { amount: 2500, category: 'expense', label: 'Transport', note: 'Fuel and Careem rides', date: new Date('2026-04-07') },
    { amount: 3000, category: 'expense', label: 'Food', note: 'Dining out', date: new Date('2026-04-10') },
    { amount: 15000, category: 'income', label: 'Freelance', note: 'Web design project', date: new Date('2026-04-12') },
    { amount: 1500, category: 'expense', label: 'Entertainment', note: 'Netflix + Spotify', date: new Date('2026-04-14') },
    { amount: 8000, category: 'expense', label: 'Shopping', note: 'New clothes', date: new Date('2026-04-16') },
    { amount: 4000, category: 'expense', label: 'Health', note: 'Doctor visit + medicine', date: new Date('2026-04-18') },
    { amount: 75000, category: 'income', label: 'Salary', note: 'Monthly salary March', date: new Date('2026-03-01') },
    { amount: 5000, category: 'expense', label: 'Groceries', note: 'Weekly groceries', date: new Date('2026-03-05') },
    { amount: 12000, category: 'expense', label: 'Rent', note: 'Monthly rent', date: new Date('2026-03-05') },
    { amount: 6000, category: 'expense', label: 'Utilities', note: 'Electricity + Gas', date: new Date('2026-03-10') },
    { amount: 2000, category: 'expense', label: 'Education', note: 'Online course', date: new Date('2026-03-15') },
  ]);

  // ========== FOOD DELIVERY ==========
  const restaurants = await Restaurant.insertMany([
    { name: 'Spicy Thai Kitchen', cuisine: 'Thai', rating: 4.8, image: 'https://images.unsplash.com/photo-1559314809-0d155014e29e?w=500&q=80', deliveryTime: '25-35 min', deliveryFee: 1.99, minOrder: 15, address: '123 Food Street', isOpen: true },
    { name: 'Burger Joint', cuisine: 'American', rating: 4.2, image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=500&q=80', deliveryTime: '20-30 min', deliveryFee: 2.49, minOrder: 10, address: '456 Main Ave', isOpen: true },
    { name: 'Sushi Zen', cuisine: 'Japanese', rating: 4.9, image: 'https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=500&q=80', deliveryTime: '35-50 min', deliveryFee: 3.99, minOrder: 20, address: '789 Ocean Blvd', isOpen: true },
    { name: 'Pizza Paradise', cuisine: 'Italian', rating: 4.5, image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=500&q=80', deliveryTime: '30-40 min', deliveryFee: 1.49, minOrder: 12, address: '321 Roma St', isOpen: true },
    { name: 'Biryani House', cuisine: 'Pakistani', rating: 4.7, image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=500&q=80', deliveryTime: '25-40 min', deliveryFee: 0.99, minOrder: 8, address: '555 Desi Lane', isOpen: true },
    { name: 'Dragon Wok', cuisine: 'Chinese', rating: 4.3, image: 'https://images.unsplash.com/photo-1525755662778-989d0524087e?w=500&q=80', deliveryTime: '30-45 min', deliveryFee: 2.99, minOrder: 15, address: '888 China Town', isOpen: true },
  ]);

  // Menu Items for each restaurant
  const menuData = [
    // Spicy Thai
    { rIdx: 0, items: [
      { name: 'Pad Thai', description: 'Classic stir-fried rice noodles', price: 12.99, category: 'Main Course', isPopular: true, image: 'https://images.unsplash.com/photo-1559314809-0d155014e29e?w=300&q=80' },
      { name: 'Green Curry', description: 'Creamy coconut green curry', price: 14.99, category: 'Main Course', isPopular: true, image: 'https://images.unsplash.com/photo-1455619452474-d2be8b1e70cd?w=300&q=80' },
      { name: 'Spring Rolls', description: 'Crispy vegetable spring rolls', price: 6.99, category: 'Starters', image: 'https://images.unsplash.com/photo-1548507200-ffe9f6006c50?w=300&q=80' },
      { name: 'Mango Sticky Rice', description: 'Sweet mango with sticky rice', price: 8.99, category: 'Desserts', image: 'https://images.unsplash.com/photo-1621293954908-907159247fc8?w=300&q=80' },
    ]},
    // Burger Joint
    { rIdx: 1, items: [
      { name: 'Classic Cheeseburger', description: 'Angus beef with cheddar', price: 11.99, category: 'Burgers', isPopular: true, image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=300&q=80' },
      { name: 'Chicken Wings', description: 'Buffalo wings with ranch', price: 9.99, category: 'Starters', isPopular: true, image: 'https://images.unsplash.com/photo-1567620832903-9fc6debc209f?w=300&q=80' },
      { name: 'Loaded Fries', description: 'Fries with cheese and bacon', price: 7.99, category: 'Sides', image: 'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?w=300&q=80' },
      { name: 'Milkshake', description: 'Creamy vanilla milkshake', price: 5.99, category: 'Drinks', image: 'https://images.unsplash.com/photo-1572490122747-3968b75cc699?w=300&q=80' },
    ]},
    // Sushi Zen
    { rIdx: 2, items: [
      { name: 'Salmon Nigiri', description: 'Fresh salmon on seasoned rice', price: 16.99, category: 'Sushi', isPopular: true, image: 'https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=300&q=80' },
      { name: 'Dragon Roll', description: 'Eel, avocado, cucumber', price: 18.99, category: 'Sushi', isPopular: true, image: 'https://images.unsplash.com/photo-1617196034796-73dfa7b1fd56?w=300&q=80' },
      { name: 'Miso Soup', description: 'Traditional Japanese miso', price: 4.99, category: 'Starters', image: 'https://images.unsplash.com/photo-1607301405390-d831c242f59b?w=300&q=80' },
      { name: 'Tempura', description: 'Crispy shrimp tempura', price: 13.99, category: 'Main Course', image: 'https://images.unsplash.com/photo-1581184953963-d15972933db1?w=300&q=80' },
    ]},
    // Pizza Paradise
    { rIdx: 3, items: [
      { name: 'Margherita Pizza', description: 'Classic tomato, mozzarella, basil', price: 13.99, category: 'Pizza', isPopular: true, image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=300&q=80' },
      { name: 'Pepperoni Pizza', description: 'Loaded pepperoni with cheese', price: 15.99, category: 'Pizza', isPopular: true, image: 'https://images.unsplash.com/photo-1628840042765-356cda07504e?w=300&q=80' },
      { name: 'Garlic Bread', description: 'Toasted garlic bread with herbs', price: 5.99, category: 'Starters', image: 'https://images.unsplash.com/photo-1619535860434-ba1d8fa12536?w=300&q=80' },
      { name: 'Tiramisu', description: 'Classic Italian coffee cake', price: 7.99, category: 'Desserts', image: 'https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?w=300&q=80' },
    ]},
    // Biryani House
    { rIdx: 4, items: [
      { name: 'Chicken Biryani', description: 'Fragrant basmati rice with spiced chicken', price: 10.99, category: 'Main Course', isPopular: true, image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=300&q=80' },
      { name: 'Seekh Kebab', description: 'Grilled minced meat kebabs', price: 8.99, category: 'Starters', isPopular: true, image: 'https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?w=300&q=80' },
      { name: 'Naan', description: 'Freshly baked flatbread', price: 2.99, category: 'Sides', image: 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=300&q=80' },
      { name: 'Gulab Jamun', description: 'Sweet milk dumplings in syrup', price: 4.99, category: 'Desserts', image: 'https://images.unsplash.com/photo-1666190020430-db0f5792dfda?w=300&q=80' },
    ]},
    // Dragon Wok
    { rIdx: 5, items: [
      { name: 'Kung Pao Chicken', description: 'Spicy stir-fried chicken with peanuts', price: 13.99, category: 'Main Course', isPopular: true, image: 'https://images.unsplash.com/photo-1525755662778-989d0524087e?w=300&q=80' },
      { name: 'Fried Rice', description: 'Wok-fried rice with vegetables', price: 9.99, category: 'Main Course', image: 'https://images.unsplash.com/photo-1603133872878-684f208fb84b?w=300&q=80' },
      { name: 'Dim Sum', description: 'Steamed dumplings assortment', price: 11.99, category: 'Starters', isPopular: true, image: 'https://images.unsplash.com/photo-1496116218417-1a781b1c416c?w=300&q=80' },
      { name: 'Fortune Cookie', description: 'Classic fortune cookie', price: 1.99, category: 'Desserts', image: 'https://images.unsplash.com/photo-1590080875515-8a3a8dc5735e?w=300&q=80' },
    ]},
  ];

  for (const md of menuData) {
    const r = restaurants[md.rIdx];
    for (const item of md.items) {
      await MenuItem.create({ ...item, restaurantId: r._id });
    }
  }

  // Orders
  await Order.insertMany([
    { orderId: 'ORD-001', date: new Date('2026-04-10'), totalPrice: 45.99, status: 'Delivered', items: [{name: 'Pad Thai', quantity: 2, price: 12.99}, {name: 'Spring Rolls', quantity: 1, price: 6.99}], restaurantName: 'Spicy Thai Kitchen', deliveryAddress: '123 Home St', estimatedTime: '25-35 min' },
    { orderId: 'ORD-002', date: new Date('2026-04-15'), totalPrice: 31.97, status: 'Delivered', items: [{name: 'Classic Cheeseburger', quantity: 1, price: 11.99}, {name: 'Loaded Fries', quantity: 1, price: 7.99}, {name: 'Milkshake', quantity: 2, price: 5.99}], restaurantName: 'Burger Joint', deliveryAddress: '456 Work Ave', estimatedTime: '20-30 min' },
    { orderId: 'ORD-003', date: new Date('2026-04-20'), totalPrice: 52.97, status: 'On the way', items: [{name: 'Dragon Roll', quantity: 2, price: 18.99}, {name: 'Miso Soup', quantity: 1, price: 4.99}, {name: 'Tempura', quantity: 1, price: 13.99}], restaurantName: 'Sushi Zen', deliveryAddress: '789 Downtown', estimatedTime: '35-50 min' },
  ]);

  console.log('Database seeded successfully!');
};

module.exports = generateRandomData;
