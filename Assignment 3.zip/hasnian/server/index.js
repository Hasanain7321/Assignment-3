require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { Product, Review, User, Post, Comment, Event, Seat, TicketBooking, Transaction, Restaurant, MenuItem, Order } = require('./models');
const seedData = require('./seedData');

const app = express();
app.use(cors());
app.use(express.json());

const MONGODB_URI = "mongodb://faseumm:fasi-123@ac-qkomsy9-shard-00-00.m4hzbl9.mongodb.net:27017,ac-qkomsy9-shard-00-01.m4hzbl9.mongodb.net:27017,ac-qkomsy9-shard-00-02.m4hzbl9.mongodb.net:27017/?ssl=true&replicaSet=atlas-nd1uij-shard-0&authSource=admin&retryWrites=true&w=majority";
const JWT_SECRET = process.env.JWT_SECRET || 'assignment3-secret-key';

let isConnected = false;
mongoose.connect(MONGODB_URI)
  .then(() => { isConnected = true; console.log('Connected to MongoDB'); })
  .catch(err => console.error('Could not connect to MongoDB', err.message));

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d).{8,}$/;
const usernameRegex = /^[a-zA-Z0-9_.-]{3,20}$/;

const getToken = (user) => jwt.sign({ id: user._id }, JWT_SECRET, { expiresIn: '7d' });
const sanitizeUser = (user) => ({
  _id: user._id,
  name: user.name || '',
  email: user.email,
  phone: user.phone || '',
  username: user.username || '',
  avatar: user.avatar || '',
  bio: user.bio || '',
});

const authMiddleware = async (req, res, next) => {
  try {
    const auth = req.headers.authorization || '';
    const token = auth.startsWith('Bearer ') ? auth.slice(7) : null;
    if (!token) return res.status(401).json({ error: 'Unauthorized' });
    const payload = jwt.verify(token, JWT_SECRET);
    const user = await User.findById(payload.id);
    if (!user) return res.status(401).json({ error: 'Unauthorized' });
    req.user = user;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid token' });
  }
};

// ========== AUTH ==========
app.post('/api/auth/signup', async (req, res) => {
  try {
    const { name, email, password, username } = req.body;
    const safeName = String(name || '').trim();
    const safeEmail = String(email || '').trim().toLowerCase();
    const safeUsername = String(username || '').trim();
    if (!name || !email || !password || !username) return res.status(400).json({ error: 'All fields are required' });
    if (!emailRegex.test(safeEmail)) return res.status(400).json({ error: 'Invalid email format' });
    if (!passwordRegex.test(password)) return res.status(400).json({ error: 'Password must be at least 8 chars and include letters and numbers' });
    if (!usernameRegex.test(safeUsername)) return res.status(400).json({ error: 'Username must be 3-20 chars and only letters, numbers, _, -, .' });
    const [existingEmail, existingUsername] = await Promise.all([
      User.findOne({ email: safeEmail }),
      User.findOne({ username: safeUsername }),
    ]);
    if (existingEmail) return res.status(409).json({ error: 'Email already registered' });
    if (existingUsername) return res.status(409).json({ error: 'Username already in use' });

    const passwordHash = await bcrypt.hash(password, 10);
    const user = await User.create({
      name: safeName,
      email: safeEmail,
      username: safeUsername,
      passwordHash,
      avatar: `https://api.dicebear.com/8.x/thumbs/png?seed=${encodeURIComponent(safeUsername)}`,
    });
    const token = getToken(user);
    res.status(201).json({ token, user: sanitizeUser(user) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/auth/signin', async (req, res) => {
  try {
    const { email, password } = req.body;
    const safeEmail = String(email || '').trim().toLowerCase();
    if (!email || !password) return res.status(400).json({ error: 'Email and password are required' });
    if (!emailRegex.test(safeEmail)) return res.status(400).json({ error: 'Invalid email format' });
    const user = await User.findOne({ email: safeEmail });
    if (!user || !user.passwordHash) return res.status(401).json({ error: 'Invalid credentials' });
    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) return res.status(401).json({ error: 'Invalid credentials' });
    const token = getToken(user);
    res.json({ token, user: sanitizeUser(user) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/auth/me', authMiddleware, async (req, res) => {
  res.json({ user: sanitizeUser(req.user) });
});

app.put('/api/auth/profile', authMiddleware, async (req, res) => {
  try {
    const { name, phone, username, bio, avatar } = req.body;
    req.user.name = name ?? req.user.name;
    req.user.phone = phone ?? req.user.phone;
    req.user.username = username ?? req.user.username;
    req.user.bio = bio ?? req.user.bio;
    req.user.avatar = avatar ?? req.user.avatar;
    await req.user.save();
    res.json({ user: sanitizeUser(req.user) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ========== ADMIN ==========
app.post('/api/seed', async (req, res) => {
  try { await seedData(); res.json({ message: 'Database seeded successfully' }); }
  catch (err) { res.status(500).json({ error: err.message }); }
});

// ========== E-COMMERCE ==========
app.get('/api/products', async (req, res) => {
  try {
    const { category, search } = req.query;
    let query = {};
    if (category && category !== 'All') query.category = category;
    if (search) query.name = new RegExp(search, 'i');
    const products = await Product.find(query);
    res.json(products);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/products/:id', async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) return res.status(404).json({ message: 'Not found' });
    res.json(product);
  } catch (err) { res.status(400).json({ error: 'Invalid ID' }); }
});

app.get('/api/products/:id/reviews', async (req, res) => {
  try {
    const reviews = await Review.find({ productId: req.params.id }).sort({ date: -1 });
    res.json(reviews);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/products/:id/reviews', async (req, res) => {
  try {
    const review = await Review.create({ ...req.body, productId: req.params.id });
    res.status(201).json(review);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/categories', async (req, res) => {
  try {
    const cats = await Product.distinct('category');
    res.json(['All', ...cats]);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ========== SOCIAL MEDIA ==========
app.get('/api/posts', async (req, res) => {
  try {
    const posts = await Post.find().populate('userId').sort({ createdAt: -1 });
    res.json(posts);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/posts/:id', async (req, res) => {
  try {
    const post = await Post.findById(req.params.id).populate('userId');
    res.json(post);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/posts', async (req, res) => {
  try {
    const post = await Post.create(req.body);
    const populated = await Post.findById(post._id).populate('userId');
    res.status(201).json(populated);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.put('/api/posts/:id/like', async (req, res) => {
  try {
    const post = await Post.findByIdAndUpdate(req.params.id, { $inc: { likes: 1 } }, { new: true });
    res.json(post);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/posts/:id/comments', async (req, res) => {
  try {
    const comments = await Comment.find({ postId: req.params.id }).sort({ createdAt: -1 });
    res.json(comments);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/posts/:id/comments', async (req, res) => {
  try {
    const comment = await Comment.create({ ...req.body, postId: req.params.id });
    await Post.findByIdAndUpdate(req.params.id, { $inc: { commentsCount: 1 } });
    res.status(201).json(comment);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/users', async (req, res) => {
  try { const users = await User.find().select('-passwordHash'); res.json(users); }
  catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/users/:id', async (req, res) => {
  try { const user = await User.findById(req.params.id).select('-passwordHash'); res.json(user); }
  catch (err) { res.status(500).json({ error: err.message }); }
});

app.put('/api/users/:id', async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(req.params.id, req.body, { new: true }).select('-passwordHash');
    res.json(user);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/users/:id/posts', async (req, res) => {
  try {
    const posts = await Post.find({ userId: req.params.id }).sort({ createdAt: -1 });
    res.json(posts);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ========== TICKET BOOKING ==========
const pakistanRoutes = [
  { id: 'PK-001', from: 'Lahore', to: 'Islamabad', busName: 'Daewoo Express', fare: 2200, departure: '08:00 AM' },
  { id: 'PK-002', from: 'Karachi', to: 'Hyderabad', busName: 'Faisal Movers', fare: 1400, departure: '10:30 AM' },
  { id: 'PK-003', from: 'Peshawar', to: 'Lahore', busName: 'Niazi Express', fare: 2600, departure: '09:15 PM' },
  { id: 'PK-004', from: 'Islamabad', to: 'Multan', busName: 'Skyways', fare: 2100, departure: '03:00 PM' },
];

app.get('/api/routes', (req, res) => {
  const { from, to } = req.query;
  const routes = pakistanRoutes.filter((route) => {
    const fromMatch = !from || route.from.toLowerCase() === String(from).toLowerCase();
    const toMatch = !to || route.to.toLowerCase() === String(to).toLowerCase();
    return fromMatch && toMatch;
  });
  res.json(routes);
});

app.get('/api/tickets', authMiddleware, async (req, res) => {
  try {
    const tickets = await TicketBooking.find({ userId: req.user._id }).sort({ createdAt: -1 });
    res.json(tickets);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/tickets', authMiddleware, async (req, res) => {
  try {
    const { from, to, busName, travelDate, gender, fare } = req.body;
    if (!from || !to || !busName || !travelDate || !gender) return res.status(400).json({ error: 'Missing required fields' });
    const ticket = await TicketBooking.create({
      userId: req.user._id, from, to, busName, travelDate, gender, fare: fare || 1200, isBooked: true,
    });
    res.status(201).json(ticket);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/events', async (req, res) => {
  try {
    const { name, category } = req.query;
    let query = {};
    if (name) query.title = new RegExp(name, 'i');
    if (category && category !== 'All') query.category = category;
    const events = await Event.find(query);
    res.json(events);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/events/:id', async (req, res) => {
  try { const event = await Event.findById(req.params.id); res.json(event); }
  catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/events/:id/seats', async (req, res) => {
  try {
    const seats = await Seat.find({ eventId: req.params.id });
    res.json(seats);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.put('/api/seats/:id/book', async (req, res) => {
  try {
    const seat = await Seat.findByIdAndUpdate(req.params.id, { isBooked: true }, { new: true });
    res.json(seat);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ========== EXPENSE TRACKER ==========
app.get('/api/transactions', async (req, res) => {
  try {
    const transactions = await Transaction.find().sort({ date: -1 });
    res.json(transactions);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/transactions', async (req, res) => {
  try {
    const transaction = await Transaction.create(req.body);
    res.status(201).json(transaction);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.delete('/api/transactions/:id', async (req, res) => {
  try {
    await Transaction.findByIdAndDelete(req.params.id);
    res.json({ message: 'Deleted' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ========== FOOD DELIVERY ==========
app.get('/api/restaurants', async (req, res) => {
  try {
    const { cuisine } = req.query;
    let query = {};
    if (cuisine && cuisine !== 'All') query.cuisine = cuisine;
    const restaurants = await Restaurant.find(query);
    res.json(restaurants);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/restaurants/:id', async (req, res) => {
  try { const r = await Restaurant.findById(req.params.id); res.json(r); }
  catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/restaurants/:id/menu', async (req, res) => {
  try {
    const items = await MenuItem.find({ restaurantId: req.params.id });
    res.json(items);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/orders', async (req, res) => {
  try {
    const orders = await Order.find().sort({ date: -1 });
    res.json(orders);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/orders/:id', async (req, res) => {
  try { const order = await Order.findById(req.params.id); res.json(order); }
  catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/orders', async (req, res) => {
  try {
    const count = await Order.countDocuments();
    const order = await Order.create({ ...req.body, orderId: `ORD-${String(count + 1).padStart(3, '0')}` });
    res.status(201).json(order);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

const PORT = 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
