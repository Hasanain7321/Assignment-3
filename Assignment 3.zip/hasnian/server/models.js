const mongoose = require('mongoose');

// ===================== E-COMMERCE =====================
const ProductSchema = new mongoose.Schema({
  name: String,
  image: String,
  price: Number,
  description: String,
  category: { type: String, default: 'General' },
  rating: { type: Number, default: 4.0 },
  reviewCount: { type: Number, default: 0 },
  inStock: { type: Boolean, default: true },
  brand: String,
});
const Product = mongoose.model('Product', ProductSchema);

const ReviewSchema = new mongoose.Schema({
  productId: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
  userName: String,
  rating: { type: Number, min: 1, max: 5 },
  comment: String,
  date: { type: Date, default: Date.now },
});
const Review = mongoose.model('Review', ReviewSchema);

// ===================== SOCIAL MEDIA =====================
const UserSchema = new mongoose.Schema({
  name: { type: String, trim: true },
  email: { type: String, trim: true, lowercase: true, index: true },
  passwordHash: String,
  phone: String,
  username: { type: String, trim: true, index: true },
  avatar: String,
  bio: { type: String, default: '' },
  followers: { type: Number, default: 0 },
  following: { type: Number, default: 0 },
  postsCount: { type: Number, default: 0 },
});
const User = mongoose.model('User', UserSchema);

const PostSchema = new mongoose.Schema({
  title: String,
  body: String,
  image: String,
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  likes: { type: Number, default: 0 },
  commentsCount: { type: Number, default: 0 },
  createdAt: { type: Date, default: Date.now },
});
const Post = mongoose.model('Post', PostSchema);

const CommentSchema = new mongoose.Schema({
  postId: { type: mongoose.Schema.Types.ObjectId, ref: 'Post' },
  userName: String,
  userAvatar: String,
  text: String,
  createdAt: { type: Date, default: Date.now },
});
const Comment = mongoose.model('Comment', CommentSchema);

// ===================== TICKET BOOKING =====================
const EventSchema = new mongoose.Schema({
  title: String,
  poster: String,
  releaseDate: Date,
  category: { type: String, default: 'Movie' },
  venue: String,
  duration: String,
  description: String,
  language: { type: String, default: 'English' },
});
const Event = mongoose.model('Event', EventSchema);

const SeatSchema = new mongoose.Schema({
  eventId: { type: mongoose.Schema.Types.ObjectId, ref: 'Event' },
  seatNumber: String,
  isBooked: Boolean,
  seatClass: { type: String, default: 'Standard' }, // 'VIP' or 'Standard'
  price: { type: Number, default: 500 },
});
const Seat = mongoose.model('Seat', SeatSchema);

const TicketBookingSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  from: { type: String, required: true },
  to: { type: String, required: true },
  busName: { type: String, required: true },
  travelDate: { type: Date, required: true },
  gender: { type: String, enum: ['male', 'female'], required: true },
  fare: { type: Number, default: 1200 },
  isBooked: { type: Boolean, default: true },
}, { timestamps: true });
const TicketBooking = mongoose.model('TicketBooking', TicketBookingSchema);

// ===================== EXPENSE TRACKER =====================
const TransactionSchema = new mongoose.Schema({
  amount: Number,
  category: String, // 'income' or 'expense'
  label: { type: String, default: 'General' }, // e.g., 'Groceries', 'Salary'
  note: String,
  date: { type: Date, default: Date.now },
});
const Transaction = mongoose.model('Transaction', TransactionSchema);

// ===================== FOOD DELIVERY =====================
const RestaurantSchema = new mongoose.Schema({
  name: String,
  cuisine: String,
  rating: Number,
  image: String,
  deliveryTime: { type: String, default: '30-45 min' },
  deliveryFee: { type: Number, default: 2.99 },
  minOrder: { type: Number, default: 10 },
  address: String,
  isOpen: { type: Boolean, default: true },
});
const Restaurant = mongoose.model('Restaurant', RestaurantSchema);

const MenuItemSchema = new mongoose.Schema({
  restaurantId: { type: mongoose.Schema.Types.ObjectId, ref: 'Restaurant' },
  name: String,
  description: String,
  price: Number,
  image: String,
  category: { type: String, default: 'Main Course' },
  isPopular: { type: Boolean, default: false },
});
const MenuItem = mongoose.model('MenuItem', MenuItemSchema);

const OrderSchema = new mongoose.Schema({
  orderId: String,
  date: { type: Date, default: Date.now },
  totalPrice: Number,
  status: { type: String, default: 'Preparing' },
  items: [{ name: String, quantity: Number, price: Number }],
  restaurantName: String,
  deliveryAddress: { type: String, default: '123 Main St' },
  estimatedTime: { type: String, default: '30-45 min' },
});
const Order = mongoose.model('Order', OrderSchema);

module.exports = {
  Product, Review,
  User, Post, Comment,
  Event, Seat, TicketBooking,
  Transaction,
  Restaurant, MenuItem, Order,
};
